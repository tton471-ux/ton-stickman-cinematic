# TON STICKMAN CINEMATIC STUDIO PRO

Thai-first React + Vite web app with an Express backend proxy for Gemini API calls.

## Run locally

1. Install Node.js 20+.
2. Run `npm install`.
3. Copy `.env.example` to `.env` and set `GEMINI_API_KEY`.
4. Build the frontend: `npm run build`.
5. Start the web server: `npm start`.
6. Open `http://localhost:10000`.

For frontend-only development, use `npm run dev`; the API proxy expects the Express server on port 10000.

## Deploy to Render

- Create a **Web Service** from this repository.
- Build Command: `npm install && npm run build`
- Start Command: `npm start`
- Add secret Environment Variable `GEMINI_API_KEY` in Render. Never commit `.env` or put the key in frontend code.
- Optional: set `GEMINI_IMAGE_MODEL` and `GEMINI_TEXT_MODEL` if your Google AI Studio project uses different model IDs.

The Express server serves the built Vite site and proxies `/api/gemini/image` and `/api/gemini/text`. The API key stays on the server. API calls are rate-limited per IP.

## Current limitations

This package converts the supplied React app into a deployable website and secures Gemini calls behind the server. Project and custom-style persistence in the supplied app still uses browser LocalStorage, so it is local to each browser/device and is not yet a shared cloud database. Actual image/text generation requires a valid Gemini API key and model access. This app does not yet generate final MP4 video; video rendering, TTS, music generation, cloud jobs, accounts, and shared cloud storage require further implementation.
