import React, { useState, useEffect, useRef } from 'react';
import { 
  Clapperboard, Sparkles, Film, Palette, Users, Image as ImageIcon, 
  Volume2, Music, Download, Settings, Play, CheckCircle2, AlertCircle, 
  Plus, Eye, Save, Trash2, ArrowRight, ArrowLeft, RefreshCw, Layers, 
  Sliders, ShieldCheck, Copy, Check, Upload, Wand2, Monitor, Smartphone, 
  Square, Video, FileText, ChevronRight, HelpCircle, Terminal, X, Lock
} from 'lucide-react';

// ==========================================
// CONSTANTS & INITIAL DATA STRUCTURES
// ==========================================
const API_MODELS = {
  IMAGE: 'gemini-3.1-flash-image',
  IMAGE_LITE: 'gemini-3.1-flash-lite-image',
  TEXT: 'gemini-3-flash-preview',
  TTS: 'gemini-2.5-flash-preview-tts'
};

const DEFAULT_BENCHMARK_PROMPT = "TON — minimalist 2D stickman character with round head, thin single-line arms and legs (2px clean stroke), cyan headband. Scene: standing on a skyscraper rooftop overlooking a vibrant city at twilight, dramatic wind blowing headband ribbons.";

// 8 INITIAL VISUAL STYLES WITH BESPOKE SPECS
const PRESET_VISUAL_STYLES = [
  {
    id: 'classic-stickman',
    nameTh: 'Classic Stickman (สไตล์ดั้งเดิม)',
    nameEn: 'Classic Stickman 2D',
    badge: 'Original Minimal',
    shortDesc: 'ลายเส้นเรียบง่าย เส้นแขนขาเดี่ยว ไม่หนาเป็นท่อ ฉากหลังคลีนบนกระดาษ/สตูดิโอ',
    desc: 'สไตล์คลาสสิกอันเป็นเอกลักษณ์ เน้นความเรียบง่ายระดับมินิมอล ลายเส้นดำคม 2px ตัวละครมีแขนขาเป็นเส้นเดี่ยว (thin single-line limbs) หัวกลมสะอาด ตาจุด ดำเนินเรื่องเน้นท่าทาง movement ที่ทรงพลังบนฉากหลังขาว/เทาอ่อนสไตล์ภาพร่างสตูดิโอ',
    characterRules: 'แขนขาต้องเป็นเส้นเดี่ยวบาง (Single-line stroke) ห้ามทำแขนขาเป็นท่อหนา (No thick tube limbs) หัวเป็นวงกลมสมบูรณ์ คาดผ้าพันหัวสีฟ้า Cyan',
    environment: 'ฉากหลังมินิมอล พื้นผิวสีกระดาษอาร์ตเวิร์ก หรือสตูดิโอ 2D ลายเส้นร่างจางๆ',
    lighting: 'แสงสว่างทั่วถึงแบบ Flat Studio Light ไร้เงารกตา เน้นความคมชัดของ Action',
    colorSwatches: ['#000000', '#06b6d4', '#ffffff', '#e2e8f0', '#64748b'],
    animationStyle: 'Exaggerated 2D keyframes, snappy timing, clean vector silhouette motion',
    cameraDirection: 'Orthographic / Eye-level static & clean panning shots',
    promptTokens: 'minimalist 2D stickman animation style, clean black stroke line art (2px thin single-line limbs, round head, cyan headband), crisp white studio backdrop, expressive vector silhouette, high contrast, clean minimalist art',
    svgType: 'classic'
  },
  {
    id: 'cinematic-stickman',
    nameTh: 'Cinematic Stickman (สไตล์ภาพยนตร์สมจริง)',
    nameEn: 'Cinematic Atmospheric Stickman',
    badge: 'Pro Recommended',
    shortDesc: 'ตัวละคร Stickman เส้นเดี่ยว ผสมฉาก 3D Parallax มีหมอก แสงริมไลท์ และเลนส์แฟลร์',
    desc: 'ยกระดับ Stickman สู่ระดับฮอลลีวูด ตัวละครคงความมินิมอลลายเส้นเดี่ยว แต่บรรยากาศโดยรอบจัดเต็มด้วยแสง Volumetric Rim Light หมอกควัน ละอองฝุ่น ฉากหลังมิติ Parallax ความลึกระดับภาพยนตร์ Anamorphic lens flare และเงาสะท้อนที่สมจริง',
    characterRules: 'สัดส่วน Stickman ลายเส้นเดี่ยว (thin single-line stroke) สีดำเข้ม มีขอบแสงสะท้อน Rim Light สีฟ้าตามขอบเส้น',
    environment: 'เมืองไซเบอร์พังค์ยามค่ำคืน หรือซากโบราณสถาน มีหมอกควัน ฉากหลังมีความละเอียดและความลึกตื้น (Depth of field)',
    lighting: 'Volumetric backlight, dramatic rim lighting, moody atmospheric fog, cyan/orange color grading',
    colorSwatches: ['#090d16', '#06b6d4', '#f59e0b', '#1e293b', '#38bdf8'],
    animationStyle: 'Fluid 60fps cinematic physics, slow-motion impacts, dramatic particle effects',
    cameraDirection: 'Anamorphic wide-angle, low camera angle, cinematic parallax panning, tracking shots',
    promptTokens: 'cinematic stickman movie aesthetic, thin single-line stickman character with glowing cyan headband, dramatic volumetric rim lighting, fog, atmospheric depth of field, detailed cinematic background, anamorphic lens flare, photorealistic environment contrasting with minimalist stickman, 8k resolution',
    svgType: 'cinematic'
  },
  {
    id: 'anime-cinematic',
    nameTh: 'Anime Cinematic (อนิเมะไซไฟเข้มข้น)',
    nameEn: 'Anime Cinematic Style',
    badge: 'Popular',
    shortDesc: 'ภาพอนิเมะ Cel-shaded ฉากท้องฟ้าและนีออนสไตล์ Makoto Shinkai ลายเส้นเงาสะท้อน',
    desc: 'ผสมผสานความเท่ของ Stickman เข้ากับลายเส้นอนิเมะญี่ปุ่นระดับมูฟวี่ แสง Cel-shaded คมชัด ฉากหลังท้องฟ้าสีชมพูอมม่วง ท้องฟ้าดวงดาว หรือเมืองนีออนยามเย็น Speed lines ออร่าพลังงานกระจายรอบตัวละคร',
    characterRules: 'เงาร่าง Stickman สีดำตัดขอบแสงนีออน ลายเส้นเดี่ยวเพรียวลม มีออร่าสีฟ้า Cyan เปล่งออกมาเมื่อใช้พลัง',
    environment: 'ท้องฟ้าทไวไลท์เมฆละเอียดแบบ Makoto Shinkai หรือทุ่งหญ้าสะท้อนแสงดาว และเมืองไซไฟ',
    lighting: 'Cel-shaded dramatic lighting, vibrant neon highlights, glowing lens flare, sunset bloom',
    colorSwatches: ['#1e1b4b', '#8b5cf6', '#06b6d4', '#f43f5e', '#fef08a'],
    animationStyle: 'High-octane anime action, speed lines, impact frames, dynamic aura burst',
    cameraDirection: 'Dynamic dutch angles, fast zoom-ins, dramatic close-ups with speed lines',
    promptTokens: 'Japanese anime cinematic feature style, minimalist stickman hero with glowing cyan aura, Makoto Shinkai aesthetic sky at twilight, vibrant cel-shaded neon lighting, dynamic speed lines, detailed anime background environment, masterpiece rendering',
    svgType: 'anime-cinematic'
  },
  {
    id: 'cartoon-3d',
    nameTh: '3D Stylized Cartoon (3D พิกซาร์สไตล์)',
    nameEn: '3D Stylized Diorama',
    badge: '3D Render',
    shortDesc: 'โมเดล 3D นุ่มนวล Subsurface scattering ฉากจำลองขนาดจิ๋ว แสงนุ่มละมุน',
    desc: 'เปลี่ยนโลก Stickman เป็นงาน 3D Stylized สุดประณีตสไตล์ Pixar/DreamWorks ตัวละครเป็นโมเดลทรงกระบอกเคลือบเงาอ่อนๆ ฉากหลังมีลักษณะเหมือนฉากจำลอง Miniature Diorama พร้อมแสงนุ่มนวล Depth of field สมบูรณ์แบบ',
    characterRules: 'Stickman แบบ 3D ปลอกแขนขาเรียวทรงกระบอกผิวด้าน (Smooth matte finish) พร้อมหัวกลมมันวาวเล็กน้อย',
    environment: 'ฉาก 3D ไซส์มินิเอเจอร์ วัสดุไม้ คอนกรีต นุ่มนวล เสมือนของเล่นหรือโมเดลตั้งโต๊ะ',
    lighting: 'Soft directional studio lighting, subsurface scattering, ambient occlusion, gentle key-light',
    colorSwatches: ['#0f172a', '#38bdf8', '#fbbf24', '#f472b6', '#a78bfa'],
    animationStyle: 'Squash and stretch 3D keyframing, tactile claymation/toy movement weight',
    cameraDirection: 'Macro tilt-shift lens effect, smooth crane shots, shallow depth of field',
    promptTokens: '3D stylized cartoon render, Pixar animation studio quality, 3D glossy minimalist stickman character with cyan headband, miniature diorama background, soft subsurface scattering lighting, octane render style, vibrant colors, shallow depth of field',
    svgType: 'cartoon-3d'
  },
  {
    id: 'hand-drawn',
    nameTh: 'Hand-Drawn Ink & Water (งานวาดมือสีน้ำ)',
    nameEn: 'Hand-Drawn Indie Animation',
    badge: 'Artistic',
    shortDesc: 'เส้นดินสอและหมึกวาดมือ ฉากหลังกระดาษสีน้ำและสีโปสเตอร์ ได้อารมณ์อินดี้อาร์ต',
    desc: 'งานศิลปะอนิเมชันวาดมือสไตล์อินดี้ ลายเส้นหมึกและดินสอสั่นไหวอย่างมีชีวิตชีวา (Line boiling) ฉากหลังสีน้ำ/สีโปสเตอร์บนเนื้อกระดาษร้อยปอนด์ ให้ความรู้สึกอบอุ่น คลาสสิก และทรงคุณค่าทางศิลปะ',
    characterRules: 'ลายเส้นหมึกดำวาดมือขรุขระเล็กน้อย (Organic ink stroke) มีรอยพฤติกรรมหมึกซึม',
    environment: 'เนื้อกระดาษสีน้ำ (Watercolor paper texture) รอยแปรงระบายสีน้ำโทนฟ้าและน้ำตาลอ่อน',
    lighting: 'Organic paper backlight, soft watercolor diffusion, natural window light simulation',
    colorSwatches: ['#292524', '#0284c7', '#d97706', '#f5f5f4', '#78716c'],
    animationStyle: 'Frame-by-frame 12fps hand-drawn wiggle, line boiling effect, ink splashes',
    cameraDirection: 'Storybook framing, gentle watercolor zoom, artistic pan',
    promptTokens: 'hand-drawn indie animation style, organic ink line art stickman, textured watercolor paper background, gouache paint wash, sketchy pencil details, artistic storybook illustration, studio ghibli indie feel',
    svgType: 'hand-drawn'
  },
  {
    id: 'dark-cinematic',
    nameTh: 'Dark Noir Cinematic (ฟิล์มนัวร์สืบสวน)',
    nameEn: 'Dark Thriller Noir',
    badge: 'Atmospheric',
    shortDesc: 'บรรยากาศมืดมน แสงเงา Chiaroscuro เงาสะท้อนน้ำฝน แสงนีออน ลึกลับระทึกขวัญ',
    desc: 'สไตล์ฟิล์มนัวร์สืบสวนและแอ็กชันระทึกขวัญ เน้นความขัดแย้งของแสงและเงาอย่างรุนแรง (Chiaroscuro) สายฝนพัดกระหน่ำ แสงสะท้อนจากพื้นถนนเปียก และนีออนสีฟ้าเดี่ยวๆ ท่ามกลางความมืดมิด',
    characterRules: 'เงา Stickman สีดำสนิทตัดกับขอบแสงนีออน มีหยดน้ำฝนเกาะตามเส้นตัวละคร',
    environment: 'ตรอกซอยมืดซอยเปียกฝน โครงสร้างเหล็กโรงงาน หรือตึกระฟ้าท่ามกลางพายุฝน',
    lighting: 'High-contrast chiaroscuro shadows, harsh spotlights, wet rain reflections, moody cyan neon',
    colorSwatches: ['#030712', '#0891b2', '#475569', '#111827', '#94a3b8'],
    animationStyle: 'Slow methodical movement, heavy shadows, rain particle simulation',
    cameraDirection: 'Extreme low angle silhouettes, Dutch tilt, high contrast shadow framing',
    promptTokens: 'dark noir cinematic thriller style, high contrast chiaroscuro lighting, minimalist black stickman silhouette with glowing cyan headband, heavy rain night, neon reflections on wet asphalt pavement, moody suspense atmosphere, film grain',
    svgType: 'dark-cinematic'
  },
  {
    id: 'minimal-comedy',
    nameTh: 'Minimalist Comedy (ตลกมินิมอลพาสเทล)',
    nameEn: 'Flat Pastel Slapstick',
    badge: 'Fun & Bright',
    shortDesc: 'สีพาสเทลสดใส ฉากหลังแบนสะอาด ท่าทางยืดหด (Squash-and-stretch) เน้นฮา',
    desc: 'สไตล์ตลกเรียบง่ายน่ารัก เน้นโทนสีพาสเทลแบนสะอาดตา (Flat pastel) การเคลื่อนไหวของ Stickman ยืดหดเกินจริง (Squash & stretch) เหมาะสำหรับมุกตลก Slapstick, คอนเทนต์สั้น TikTok/Reels และการเล่าเรื่องเบาสมอง',
    characterRules: 'Stickman เส้นเดี่ยวโค้งมน แสดงอารมณ์ด้วยตาจุดโตๆ หรือคิ้วย่นยืดหดสุดตัว',
    environment: 'ฉากหลังแบน 2D สีพาสเทลสว่าง เช่น สีฟ้าพาสเทล เหลืองพาสเทล หรือชมพูอ่อน',
    lighting: 'Flat ambient light, absolute zero dark shadows, clean bright visual presentation',
    colorSwatches: ['#38bdf8', '#fde047', '#f472b6', '#4ade80', '#ffffff'],
    animationStyle: 'Extreme squash and stretch slapstick timing, cartoon bounce, popping icons',
    cameraDirection: 'Fixed front-view comedy stage, quick snappy jump cuts',
    promptTokens: 'bright minimalist comedy animation style, flat vector pastel art, cute stickman character with exaggerated funny pose, cyan headband, clean uncluttered background, vibrant pastel palette, slapstick cartoon aesthetic',
    svgType: 'minimal-comedy'
  },
  {
    id: 'anime-comedy',
    nameTh: 'Anime Comedy (อนิเมะตลกมังงะ)',
    nameEn: 'Manga Slapstick Energy',
    badge: 'Expressive',
    shortDesc: 'สีสันฉูดฉาด การตลกแบบมังงะ หยดน้ำฮา เส้นแอ็กชัน และเอฟเฟกต์รีแอ็กชัน',
    desc: 'สไตล์อนิเมะตลกหลุดโลก จัดเต็มด้วยสัญลักษณ์มังงะ เช่น หยดน้ำเหงื่อตก (Sweatdrops), เส้นเอฟเฟกต์ตกใจ, หัวขยายใหญ่แบบ Chibi reaction, และฉากหลังเปลี่ยนเป็นเส้นสปีดสีสดใสเมื่อปล่อยมุกตลก',
    characterRules: 'Stickman ปรับเปลี่ยนสัดส่วนได้ทันที (หัวโต ตัวเล็ก มีเหงื่อตก / ตาเป็นลายกากบาท)',
    environment: 'ฉากหลังเปลี่ยนตามอารมณ์มุกตลก เช่น พื้นหลังลายจุด หรือเส้นสปีดมังงะสีสดใส',
    lighting: 'Vibrant pop lighting, high saturation manga color burst, zero realism',
    colorSwatches: ['#fbbf24', '#ef4444', '#06b6d4', '#8b5cf6', '#10b981'],
    animationStyle: 'Chibi transformation, sweatdrop pop, manga exclamation lines, hyper motion',
    cameraDirection: 'Speed lines zoom, dramatic face reaction camera shake',
    promptTokens: 'Japanese manga anime comedy style, exaggerated stickman with huge anime sweatdrop and funny reaction face, vibrant manga background with speed lines and pop patterns, bright saturated colors, hilarious slapstick energy',
    svgType: 'anime-comedy'
  }
];

// Style categories are derived from the existing registry. The original style IDs,
// names, prompts, and bespoke specifications remain unchanged.
const STYLE_CATEGORY_BY_ID = {
  'classic-stickman': 'stickman',
  'cinematic-stickman': 'stickman',
  'minimal-comedy': 'stickman',
  'anime-comedy': 'stickman',
  'anime-cinematic': 'anime',
  'cartoon-3d': '3d',
  'hand-drawn': 'handdrawn',
  'dark-cinematic': 'noir'
};

const STYLE_CATEGORY_LABELS = [
  { id: 'all', label: 'ทั้งหมด' },
  { id: 'stickman', label: 'Stickman' },
  { id: 'anime', label: 'Anime' },
  { id: '3d', label: '3D Cartoon' },
  { id: 'handdrawn', label: 'Hand-Drawn' },
  { id: 'noir', label: 'Dark / Noir' }
];

// INITIAL SAMPLE DEMO PROJECT
const INITIAL_DEMO_PROJECT = {
  id: 'proj-ton-demo-01',
  title: 'TON : กำเนิดสติกแมนผู้พิทักษ์ (The Beginning)',
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString(),
  aspectRatio: '16:9',
  resolution: '1080p (Full HD)',
  movieLanguage: 'th',
  targetDurationMinutes: 3,
  
  // Style persistence
  visualStyleId: 'cinematic-stickman',
  visualStyleName: 'Cinematic Stickman (สไตล์ภาพยนตร์สมจริง)',
  visualStyleDescription: 'ตัวละคร Stickman เส้นเดี่ยว ผสมฉาก 3D Parallax มีหมอก แสงริมไลท์ และเลนส์แฟลร์',
  visualStylePrompt: 'cinematic stickman movie aesthetic, thin single-line stickman character with glowing cyan headband, dramatic volumetric rim lighting, fog, atmospheric depth of field',
  customStyleSettings: null,
  styleReferenceImages: [],
  generatedStylePreview: null,
  styleLocked: true,
  styleVersion: 1,
  
  // Script & Characters
  scriptConcept: 'ต้นกำเนิดของ TON สติกแมนลายเส้นมินิมอลผู้ค้นพบพลังแสงนีออนบนยอดเขาไซเบอร์ และต้องปกป้องเมืองจากเงามืด',
  screenplay: `[SCENE 1: ROOFTOP AT TWILIGHT]\nTON ยืนบนยอดตึกสูง ลมพัดผ้าพันหัวสีฟ้าพริ้วไหว สายตามองลงไปยังเมืองไซเบอร์เนติกส์\n\n[SCENE 2: SHADOW ATTACK]\nสติกแมนเงามืดโผล่มาจากความมืด TON ชักดาบแสงนีออนสีฟ้าออกมาเตรียมรับมือ\n\n[SCENE 3: FINAL BLOW]\nTON พุ่งตัวด้วยความเร็วสูง ทิ้งเส้นแสงสีฟ้ากระแทกเงามืดจนสลายไป เมืองกลับคืนสู่ความสงบ`,
  characters: [
    { name: 'TON', role: 'ตัวเอก (Hero)', desc: 'สติกแมนแขนขาเส้นเดี่ยว หัวกลม คาดผ้าพันหัวสีฟ้า Cyan กล้าหาญ', rules: 'แขนขาต้องเป็นเส้นเดี่ยว 2px ห้ามหนาเป็นท่อ' },
    { name: 'SHADOW KING', role: 'ตัวร้าย (Villain)', desc: 'สติกแมนเงามืดมีออร่าสีแดง คลุมด้วยควันสีดำ', rules: 'ร่างเงาสมบูรณ์ แขนขาเส้นเดี่ยวขรุขระ' }
  ],
  
  // Storyboards & Generation
  storyboards: [
    { scene: 1, title: 'จุดเริ่มต้นบนยอดตึก', prompt: 'TON minimalist stickman standing on skyscraper rooftop at twilight cyan headband', status: 'ready', image: null },
    { scene: 2, title: 'เงามืดปรากฏกาย', prompt: 'Dark shadow stickman villain emerging from dark smoke facing TON', status: 'ready', image: null },
    { scene: 3, title: 'การต่อสู้ด้วยดาบแสง', prompt: 'TON swinging cyan neon energy blade in cinematic action pose', status: 'ready', image: null }
  ],
  
  // Voice & Audio
  voiceTracks: [
    { scene: 1, speaker: 'TON', text: 'เมืองนี้... ฉันจะเป็นคนปกป้องมันเอง!', voiceName: 'Kore', audioUrl: null }
  ],
  musicTrack: 'Cyberpunk Cinematic Tension Synth (120 BPM)',
  renderProgress: 0,
  renderStatus: 'idle'
};

// ==========================================
// BESPOKE SVG VECTOR THUMBNAIL GENERATORS
// ==========================================
const BespokeStyleThumb = ({ styleId }) => {
  switch (styleId) {
    case 'classic-stickman':
      return (
        <svg className="w-full h-full" viewBox="0 0 300 200" fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect width="300" height="200" fill="#F8FAFC" />
          <path d="M0 160 H300" stroke="#CBD5E1" strokeWidth="1" strokeDasharray="4 4" />
          {/* Paper texture lines */}
          <line x1="25" y1="20" x2="25" y2="180" stroke="#E2E8F0" strokeWidth="2" />
          {/* Classic Stickman */}
          <circle cx="150" cy="70" r="22" stroke="#0F172A" strokeWidth="3" fill="#FFFFFF" />
          <path d="M150 92 V145" stroke="#0F172A" strokeWidth="3" strokeLinecap="round" />
          {/* Thin single-line arms */}
          <path d="M150 105 L110 125 M150 105 L195 90" stroke="#0F172A" strokeWidth="3" strokeLinecap="round" />
          {/* Thin single-line legs */}
          <path d="M150 145 L120 180 M150 145 L180 180" stroke="#0F172A" strokeWidth="3" strokeLinecap="round" />
          {/* Headband */}
          <path d="M128 65 H172" stroke="#06B6D4" strokeWidth="5" strokeLinecap="round" />
          <path d="M172 65 L185 72 L180 82" stroke="#06B6D4" strokeWidth="3" strokeLinecap="round" />
          <text x="15" y="190" fill="#94A3B8" fontSize="10" fontFamily="monospace">CANONICAL 2PX LINE ART</text>
        </svg>
      );
    case 'cinematic-stickman':
      return (
        <svg className="w-full h-full" viewBox="0 0 300 200" fill="none" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="bg-cin" x1="0" y1="0" x2="0" y2="200" gradientUnits="userSpaceOnUse">
              <stop stopColor="#0B0F19" />
              <stop offset="1" stopColor="#020617" />
            </linearGradient>
            <radialGradient id="cyan-glow" cx="150" cy="80" r="90" gradientUnits="userSpaceOnUse">
              <stop stopColor="#06B6D4" stopOpacity="0.4" />
              <stop offset="1" stopColor="#06B6D4" stopOpacity="0" />
            </radialGradient>
          </defs>
          <rect width="300" height="200" fill="url(#bg-cin)" />
          {/* City skyline silhouettes */}
          <rect x="20" y="100" width="35" height="100" fill="#0F172A" />
          <rect x="65" y="70" width="45" height="130" fill="#1E293B" />
          <rect x="180" y="80" width="50" height="120" fill="#0F172A" />
          <rect x="240" y="110" width="40" height="90" fill="#1E293B" />
          {/* Rim lights on city */}
          <line x1="65" y1="70" x2="110" y2="70" stroke="#06B6D4" strokeWidth="1.5" />
          {/* Glow */}
          <circle cx="150" cy="80" r="90" fill="url(#cyan-glow)" />
          {/* Anamorphic Flare */}
          <ellipse cx="150" cy="80" rx="140" ry="2" fill="#38BDF8" opacity="0.8" />
          {/* Atmospheric Fog */}
          <rect y="150" width="300" height="50" fill="#06B6D4" opacity="0.15" />
          {/* Stickman Hero */}
          <circle cx="150" cy="65" r="18" stroke="#06B6D4" strokeWidth="3" fill="#090D16" />
          <path d="M150 83 V130" stroke="#06B6D4" strokeWidth="3" />
          <path d="M150 95 L115 110 M150 95 L190 75" stroke="#06B6D4" strokeWidth="3" strokeLinecap="round" />
          <path d="M150 130 L125 175 M150 130 L175 175" stroke="#06B6D4" strokeWidth="3" strokeLinecap="round" />
          <path d="M132 60 H168" stroke="#38BDF8" strokeWidth="4" />
        </svg>
      );
    case 'anime-cinematic':
      return (
        <svg className="w-full h-full" viewBox="0 0 300 200" fill="none" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="anime-sky" x1="0" y1="0" x2="300" y2="200" gradientUnits="userSpaceOnUse">
              <stop stopColor="#312E81" />
              <stop offset="0.5" stopColor="#7C3AED" />
              <stop offset="1" stopColor="#DB2777" />
            </linearGradient>
          </defs>
          <rect width="300" height="200" fill="url(#anime-sky)" />
          {/* Anime Speed lines */}
          <path d="M0 0 L120 80 M300 0 L180 80 M0 200 L120 120 M300 200 L180 120" stroke="#FFFFFF" strokeWidth="1" opacity="0.3" />
          {/* Sun / Moon celestial ring */}
          <circle cx="150" cy="80" r="50" fill="none" stroke="#FDE047" strokeWidth="2" opacity="0.6" strokeDasharray="6 3" />
          {/* Anime Aura */}
          <path d="M110 140 Q150 20 190 140" stroke="#06B6D4" strokeWidth="8" opacity="0.4" fill="none" />
          {/* Anime Stickman with stance */}
          <circle cx="150" cy="65" r="16" fill="#0F172A" stroke="#38BDF8" strokeWidth="2" />
          <path d="M150 81 L145 125" stroke="#0F172A" strokeWidth="3.5" />
          <path d="M148 90 L105 75 M148 90 L195 105" stroke="#0F172A" strokeWidth="3.5" strokeLinecap="round" />
          <path d="M145 125 L110 165 M145 125 L180 165" stroke="#0F172A" strokeWidth="3.5" strokeLinecap="round" />
          {/* Energy Blade */}
          <path d="M195 105 L250 60" stroke="#06B6D4" strokeWidth="4" strokeLinecap="round" />
          <path d="M195 105 L260 50" stroke="#FFFFFF" strokeWidth="1.5" />
        </svg>
      );
    case 'cartoon-3d':
      return (
        <svg className="w-full h-full" viewBox="0 0 300 200" fill="none" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="bg-3d" x1="0" y1="0" x2="0" y2="200" gradientUnits="userSpaceOnUse">
              <stop stopColor="#1E1B4B" />
              <stop offset="1" stopColor="#312E81" />
            </linearGradient>
            <radialGradient id="sphere-head" cx="145" cy="55" r="20" gradientUnits="userSpaceOnUse">
              <stop stopColor="#38BDF8" />
              <stop offset="1" stopColor="#0284C7" />
            </radialGradient>
          </defs>
          <rect width="300" height="200" fill="url(#bg-3d)" />
          {/* Miniature Pedestal */}
          <ellipse cx="150" cy="165" rx="80" ry="20" fill="#475569" />
          <ellipse cx="150" cy="160" rx="80" ry="20" fill="#64748B" />
          {/* Soft Shadow */}
          <ellipse cx="150" cy="158" rx="35" ry="8" fill="#0F172A" opacity="0.6" />
          {/* 3D Cylindrical Limb Stickman */}
          <circle cx="150" cy="65" r="20" fill="url(#sphere-head)" />
          <rect x="144" y="85" width="12" height="45" rx="6" fill="#E2E8F0" />
          <rect x="110" y="92" width="38" height="10" rx="5" fill="#E2E8F0" transform="rotate(-15 110 92)" />
          <rect x="152" y="92" width="40" height="10" rx="5" fill="#E2E8F0" transform="rotate(20 152 92)" />
          <rect x="136" y="125" width="10" height="40" rx="5" fill="#CBD5E1" transform="rotate(-10 136 125)" />
          <rect x="154" y="125" width="10" height="40" rx="5" fill="#CBD5E1" transform="rotate(15 154 125)" />
          {/* Headband 3D pill */}
          <rect x="132" y="58" width="36" height="8" rx="4" fill="#06B6D4" />
        </svg>
      );
    case 'hand-drawn':
      return (
        <svg className="w-full h-full" viewBox="0 0 300 200" fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect width="300" height="200" fill="#F5F5F4" />
          {/* Watercolor washes */}
          <path d="M10 20 Q120 5 280 40 Q290 150 200 180 Q50 190 20 120 Z" fill="#E7E5E4" opacity="0.6" />
          <path d="M100 40 Q220 30 250 120 Q180 170 80 140 Z" fill="#BAE6FD" opacity="0.3" />
          {/* Sketchy Stickman */}
          <circle cx="150" cy="70" r="20" stroke="#292524" strokeWidth="2.5" strokeDasharray="30 2" fill="none" />
          <path d="M148 90 C152 110 147 130 151 145" stroke="#292524" strokeWidth="3" />
          <path d="M150 102 C130 115 115 110 105 120 M150 102 C170 100 185 95 200 85" stroke="#292524" strokeWidth="2.5" />
          <path d="M151 145 C135 160 125 170 115 180 M151 145 C165 160 175 168 185 178" stroke="#292524" strokeWidth="2.5" />
          {/* Watercolor splashes */}
          <circle cx="210" cy="80" r="4" fill="#0284C7" opacity="0.4" />
          <circle cx="218" cy="88" r="2" fill="#0284C7" opacity="0.5" />
          <text x="15" y="188" fill="#78716C" fontSize="10" fontFamily="serif">INK & WATERCOLOR TEXTURE</text>
        </svg>
      );
    case 'dark-cinematic':
      return (
        <svg className="w-full h-full" viewBox="0 0 300 200" fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect width="300" height="200" fill="#030712" />
          {/* Rain drops */}
          <line x1="40" y1="10" x2="30" y2="60" stroke="#38BDF8" strokeWidth="1" opacity="0.3" />
          <line x1="120" y1="20" x2="110" y2="70" stroke="#38BDF8" strokeWidth="1" opacity="0.4" />
          <line x1="220" y1="5" x2="210" y2="55" stroke="#38BDF8" strokeWidth="1" opacity="0.2" />
          <line x1="280" y1="40" x2="270" y2="90" stroke="#38BDF8" strokeWidth="1" opacity="0.3" />
          {/* Wet ground reflection */}
          <rect y="160" width="300" height="40" fill="#111827" />
          <ellipse cx="150" cy="180" rx="70" ry="6" fill="#0891B2" opacity="0.3" />
          {/* High contrast Silhouette Stickman */}
          <circle cx="150" cy="65" r="18" fill="#000000" stroke="#0891B2" strokeWidth="2" />
          <path d="M150 83 V135" stroke="#000000" strokeWidth="4" />
          <path d="M150 95 L110 115 M150 95 L190 120" stroke="#000000" strokeWidth="3.5" />
          <path d="M150 135 L120 175 M150 135 L175 175" stroke="#000000" strokeWidth="3.5" />
          {/* Cyan Neon Sign in background */}
          <rect x="220" y="30" width="50" height="80" fill="none" stroke="#0891B2" strokeWidth="2" />
          <text x="230" y="75" fill="#0891B2" fontSize="12" fontWeight="bold">NOIR</text>
        </svg>
      );
    case 'minimal-comedy':
      return (
        <svg className="w-full h-full" viewBox="0 0 300 200" fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect width="300" height="200" fill="#BAE6FD" />
          {/* Sun / Happy element */}
          <circle cx="250" cy="40" r="25" fill="#FDE047" />
          {/* Pastel Ground */}
          <rect y="150" width="300" height="50" fill="#86EFAC" />
          {/* Expressive Squash & Stretch Stickman */}
          <ellipse cx="150" cy="70" rx="22" ry="16" fill="#FFFFFF" stroke="#0284C7" strokeWidth="3" />
          <circle cx="142" cy="68" r="3" fill="#0284C7" />
          <circle cx="158" cy="68" r="3" fill="#0284C7" />
          <path d="M144 76 Q150 82 156 76" stroke="#0284C7" strokeWidth="2" fill="none" />
          {/* Squashed Body */}
          <path d="M150 86 Q160 115 150 135" stroke="#0284C7" strokeWidth="3.5" />
          <path d="M150 98 Q110 80 100 110 M150 98 Q190 80 200 110" stroke="#0284C7" strokeWidth="3" strokeLinecap="round" />
          <path d="M150 135 Q130 165 120 150 M150 135 Q170 165 180 150" stroke="#0284C7" strokeWidth="3" strokeLinecap="round" />
        </svg>
      );
    case 'anime-comedy':
      return (
        <svg className="w-full h-full" viewBox="0 0 300 200" fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect width="300" height="200" fill="#FEF08A" />
          {/* Manga Burst lines */}
          <path d="M150 100 L0 0 M150 100 L300 0 M150 100 L0 200 M150 100 L300 200 M150 100 L150 0 M150 100 L150 200" stroke="#F59E0B" strokeWidth="2" strokeDasharray="10 10" />
          {/* Chibi Shocked Stickman */}
          <circle cx="150" cy="75" r="30" fill="#FFFFFF" stroke="#1E293B" strokeWidth="3" />
          {/* Exaggerated Eyes & Mouth */}
          <ellipse cx="138" cy="70" rx="5" ry="9" fill="#1E293B" />
          <ellipse cx="162" cy="70" rx="5" ry="9" fill="#1E293B" />
          <ellipse cx="150" cy="88" rx="10" ry="12" fill="#EF4444" stroke="#1E293B" strokeWidth="2" />
          {/* Massive Anime Sweatdrop */}
          <path d="M185 50 Q195 65 185 75 Q175 65 185 50 Z" fill="#38BDF8" stroke="#1E293B" strokeWidth="2" />
          {/* Tiny Body */}
          <path d="M150 105 V145" stroke="#1E293B" strokeWidth="3" />
          <path d="M150 115 L120 135 M150 115 L180 135" stroke="#1E293B" strokeWidth="3" strokeLinecap="round" />
          <path d="M150 145 L130 180 M150 145 L170 180" stroke="#1E293B" strokeWidth="3" strokeLinecap="round" />
        </svg>
      );
    default:
      return (
        <div className="w-full h-full bg-slate-800 flex items-center justify-center text-slate-400">
          <Palette className="w-10 h-10" />
        </div>
      );
  }
};

// ==========================================
// GEMINI API CALL HELPERS
// ==========================================
async function callGeminiImageAPI({ prompt, stylePrompt, aspectRatio = "16:9", refImageBase64 = null }) {
  const response = await fetch('/api/gemini/image', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ prompt, stylePrompt, aspectRatio, refImageBase64 })
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || `Image API failed (${response.status})`);
  if (!data.image) throw new Error('เซิร์ฟเวอร์ไม่ได้ส่งภาพกลับมา');
  return data.image;
}

async function callGeminiTextAPI({ systemPrompt, userPrompt }) {
  const response = await fetch('/api/gemini/text', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ systemPrompt, userPrompt })
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || `Text API failed (${response.status})`);
  return data.text || '';
}

// ==========================================
// MAIN REACT COMPONENT
// ==========================================
export default function App() {
  // Prototype persistence state. For production, move API keys to a secure backend; do not expose them in client storage.
  const [apiConfigured, setApiConfigured] = useState(false);
  const [apiStatusChecked, setApiStatusChecked] = useState(false);
  const apiKey = apiConfigured ? 'SERVER_CONFIGURED' : ''; // status flag only; secret never reaches browser
  const [projects, setProjects] = useState(() => {
    const saved = localStorage.getItem('ton_studio_projects');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { console.error(e); }
    }
    return [INITIAL_DEMO_PROJECT];
  });
  const [customStyles, setCustomStyles] = useState(() => {
    const saved = localStorage.getItem('ton_studio_custom_styles');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { console.error(e); }
    }
    return [];
  });

  const [activeProjectId, setActiveProjectId] = useState(() => projects[0]?.id || null);
  const [currentView, setCurrentView] = useState('dashboard'); // 'dashboard', 'wizard', 'workbench', 'settings'
  const [activeTab, setActiveTab] = useState('style'); // 'overview', 'style', 'screenplay', 'characters', 'storyboard', 'images', 'prompt17', 'voice', 'music', 'render', 'diagnostics'

  // Wizard state
  const [wizardStep, setWizardStep] = useState(1);
  const [wizardData, setWizardData] = useState({
    title: '',
    aspectRatio: '16:9',
    resolution: '1080p (Full HD)',
    movieLanguage: 'th',
    targetDurationMinutes: 3,
    visualStyleId: 'cinematic-stickman',
    scriptConcept: '',
    generatedStylePreview: null
  });

  // Custom style creator state
  const [customStyleForm, setCustomStyleForm] = useState({
    nameTh: '',
    nameEn: '',
    shortDesc: '',
    promptTokens: '',
    characterRules: 'แขนขาเส้นเดี่ยวบาง (thin single-line limbs) ห้ามทำแขนขาหนาเป็นท่อ',
    refImage: null
  });
  const [customStylePreviewImg, setCustomStylePreviewImg] = useState(null);
  const [isGeneratingCustomPreview, setIsGeneratingCustomPreview] = useState(false);

  // Style Preview Modal state
  const [previewModalStyle, setPreviewModalStyle] = useState(null);
  const [previewLiveImage, setPreviewLiveImage] = useState(null);
  const [isGeneratingLivePreview, setIsGeneratingLivePreview] = useState(false);
  const [previewApiError, setPreviewApiError] = useState(null);
  const [wizardStyleFilter, setWizardStyleFilter] = useState('all');
  const [workbenchStyleFilter, setWorkbenchStyleFilter] = useState('all');

  // Style Change Guard Confirmation Modal
  const [styleChangeModal, setStyleChangeModal] = useState({ isOpen: false, targetStyle: null });

  // UI Toast Notice
  const [toast, setToast] = useState(null);

  // Diagnostics test results state
  const [testResults, setTestResults] = useState(null);

  // Active Project Reference
  const activeProject = projects.find(p => p.id === activeProjectId) || projects[0];

  // Save to localstorage on change
  useEffect(() => {
    fetch('/api/status').then(r => r.json()).then(d => setApiConfigured(Boolean(d.geminiConfigured))).catch(() => setApiConfigured(false)).finally(() => setApiStatusChecked(true));
  }, []);

  useEffect(() => {
    localStorage.setItem('ton_studio_projects', JSON.stringify(projects));
  }, [projects]);

  useEffect(() => {
    localStorage.setItem('ton_studio_custom_styles', JSON.stringify(customStyles));
  }, [customStyles]);

  const showToast = (msg, type = 'success') => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 4000);
  };

  // Combine default preset styles with user custom styles
  const allAvailableStyles = [...PRESET_VISUAL_STYLES, ...customStyles].map(style => ({
    ...style,
    category: style.category || (style.isCustom ? 'custom' : STYLE_CATEGORY_BY_ID[style.id] || 'other')
  }));
  const wizardFilteredStyles = allAvailableStyles.filter(style =>
    wizardStyleFilter === 'all' || style.category === wizardStyleFilter || (wizardStyleFilter === 'stickman' && style.category === 'custom' && style.isStickmanStyle)
  );
  const workbenchFilteredStyles = allAvailableStyles.filter(style =>
    workbenchStyleFilter === 'all' || style.category === workbenchStyleFilter || (workbenchStyleFilter === 'stickman' && style.category === 'custom' && style.isStickmanStyle)
  );

  // ==========================================
  // PROJECT ACTIONS
  // ==========================================
  const handleCreateProjectFromWizard = () => {
    if (!wizardData.title.trim()) {
      showToast('กรุณาระบุชื่อโปรเจกต์', 'error');
      return;
    }

    const selectedStyleObj = allAvailableStyles.find(s => s.id === wizardData.visualStyleId) || PRESET_VISUAL_STYLES[1];

    const newProj = {
      id: 'proj-' + Date.now(),
      title: wizardData.title,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      aspectRatio: wizardData.aspectRatio,
      resolution: wizardData.resolution,
      movieLanguage: wizardData.movieLanguage,
      targetDurationMinutes: wizardData.targetDurationMinutes,

      visualStyleId: selectedStyleObj.id,
      visualStyleName: selectedStyleObj.nameTh || selectedStyleObj.name,
      visualStyleDescription: selectedStyleObj.shortDesc,
      visualStylePrompt: selectedStyleObj.promptTokens,
      customStyleSettings: selectedStyleObj.isCustom ? selectedStyleObj : null,
      styleReferenceImages: selectedStyleObj.refImage ? [selectedStyleObj.refImage] : [],
      generatedStylePreview: wizardData.generatedStylePreview,
      styleLocked: true,
      styleVersion: 1,

      scriptConcept: wizardData.scriptConcept || 'เรื่องราวการผจญภัยของ TON สติกแมนฮีโร่',
      screenplay: `[SCENE 1: OPENING]\nการเปิดฉากเล่าเรื่องราวตามแนวคิดภาพยนตร์ที่กำหนดในสไตล์ ${selectedStyleObj.nameTh}\n\n[SCENE 2: CONFLICT]\nเกิดเหตุการณ์ท้าทายที่ตัวเอกต้องเผชิญ\n\n[SCENE 3: RESOLUTION]\nฉากคลายปมอย่างยิ่งใหญ่ทรงพลัง`,
      characters: [
        { name: 'TON', role: 'ตัวเอก (Hero)', desc: 'สติกแมนคาดผ้าพันหัวสีฟ้า ลายเส้นเดี่ยว 2px', rules: selectedStyleObj.characterRules || 'แขนขาเส้นเดี่ยว' }
      ],
      storyboards: [
        { scene: 1, title: 'ฉากเปิดตัวภาพยนตร์', prompt: `TON standing hero pose in ${selectedStyleObj.nameEn} style`, status: 'ready', image: wizardData.generatedStylePreview }
      ],
      voiceTracks: [],
      musicTrack: 'Cinematic Orchestral Theme',
      renderProgress: 0,
      renderStatus: 'idle'
    };

    setProjects([newProj, ...projects]);
    setActiveProjectId(newProj.id);
    setCurrentView('workbench');
    setActiveTab('overview');
    showToast(`สร้างโปรเจกต์ "${newProj.title}" สำเร็จ!`);
  };

  const handleApplyStyleToActiveProject = (styleObj) => {
    if (!activeProject || !styleObj) return;
    if (activeProject.styleLocked !== false) {
      showToast('Style Lock เปิดอยู่ กรุณาปลดล็อกสไตล์ก่อนเปลี่ยนสไตล์ภาพยนตร์', 'error');
      return;
    }

    // Require explicit confirmation after the user unlocks the project style.
    setStyleChangeModal({
      isOpen: true,
      targetStyle: styleObj
    });
  };

  const confirmStyleChange = () => {
    const styleObj = styleChangeModal.targetStyle;
    if (!styleObj || !activeProject) return;

    const updated = projects.map(p => {
      if (p.id === activeProject.id) {
        return {
          ...p,
          visualStyleId: styleObj.id,
          visualStyleName: styleObj.nameTh || styleObj.name,
          visualStyleDescription: styleObj.shortDesc,
          visualStylePrompt: styleObj.promptTokens,
          customStyleSettings: styleObj.isCustom ? styleObj : null,
          styleReferenceImages: styleObj.refImage ? [styleObj.refImage] : [],
          styleLocked: true,
          styleVersion: (p.styleVersion || 1) + 1,
          generatedStylePreview: null,
          updatedAt: new Date().toISOString()
        };
      }
      return p;
    });

    setProjects(updated);
    setStyleChangeModal({ isOpen: false, targetStyle: null });
    showToast(`เปลี่ยนสไตล์โปรเจกต์เป็น "${styleObj.nameTh || styleObj.name}" เรียบร้อยแล้ว`);
  };

  // ==========================================
  // LIVE PREVIEW GENERATION
  // ==========================================
  const handleGenerateLiveStylePreview = async (styleObj) => {
    setPreviewApiError(null);
    setIsGeneratingLivePreview(true);

    try {
      const currentAspect = activeProject ? activeProject.aspectRatio : wizardData.aspectRatio;
      const refImg = styleObj.refImage || null;

      const generatedDataUrl = await callGeminiImageAPI({
        prompt: DEFAULT_BENCHMARK_PROMPT,
        stylePrompt: `${styleObj.promptTokens}. Character rules: ${styleObj.characterRules || ''}. Environment: ${styleObj.environment || ''}. Lighting: ${styleObj.lighting || ''}. Animation: ${styleObj.animationStyle || ''}. Camera: ${styleObj.cameraDirection || ''}.`,
        aspectRatio: currentAspect,
        refImageBase64: refImg
      });

      setPreviewLiveImage(generatedDataUrl);

      // Cache to project if in wizard or workbench
      if (currentView === 'wizard') {
        setWizardData(prev => ({ ...prev, generatedStylePreview: generatedDataUrl }));
      } else if (activeProject && activeProject.visualStyleId === styleObj.id) {
        setProjects(projects.map(p => p.id === activeProject.id ? { ...p, generatedStylePreview: generatedDataUrl } : p));
      }

      showToast('สร้างภาพตัวอย่างไลฟ์พรีวิวสำเร็จ!');
    } catch (err) {
      console.error(err);
      setPreviewApiError(err.message);
    } finally {
      setIsGeneratingLivePreview(false);
    }
  };

  // ==========================================
  // CUSTOM STYLE CREATOR HANDLERS
  // ==========================================
  const handleCustomRefImageUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (uploadEvent) => {
      setCustomStyleForm(prev => ({ ...prev, refImage: uploadEvent.target.result }));
    };
    reader.readAsDataURL(file);
  };

  const handleSaveCustomStyle = () => {
    if (!customStyleForm.nameTh.trim() || !customStyleForm.promptTokens.trim()) {
      showToast('กรุณาระบุชื่อสไตล์และพรอมต์กำหนดสไตล์', 'error');
      return;
    }

    const newCustomStyle = {
      id: 'custom-style-' + Date.now(),
      isCustom: true,
      category: 'custom',
      isStickmanStyle: true,
      nameTh: customStyleForm.nameTh,
      nameEn: customStyleForm.nameEn || customStyleForm.nameTh,
      badge: 'Custom Style',
      shortDesc: customStyleForm.shortDesc || 'สไตล์ที่ปรับแต่งเองโดยผู้ใช้',
      desc: customStyleForm.shortDesc || 'สไตล์ที่กำหนดเองพร้อมภาพอ้างอิงและพรอมต์เฉพาะตัว',
      characterRules: customStyleForm.characterRules,
      environment: 'กำหนดโดยพรอมต์ผู้ใช้',
      lighting: 'กำหนดโดยพรอมต์ผู้ใช้',
      colorSwatches: ['#06b6d4', '#3b82f6', '#8b5cf6', '#ec4899', '#f59e0b'],
      animationStyle: 'Custom motion dynamics',
      cameraDirection: 'Custom camera direction',
      promptTokens: customStyleForm.promptTokens,
      refImage: customStyleForm.refImage,
      svgType: 'classic'
    };

    setCustomStyles([...customStyles, newCustomStyle]);
    setCustomStyleForm({
      nameTh: '',
      nameEn: '',
      shortDesc: '',
      promptTokens: '',
      characterRules: 'แขนขาเส้นเดี่ยวบาง (thin single-line limbs) ห้ามทำแขนขาหนาเป็นท่อ',
      refImage: null
    });
    showToast(`บันทึกสไตล์คัสตอม "${newCustomStyle.nameTh}" เรียบร้อยแล้ว!`);
  };

  // ==========================================
  // DIAGNOSTICS & SYSTEM VERIFICATION SUITE
  // ==========================================
  const runSystemDiagnostics = () => {
    const results = [];

    // Test 1: Preset Styles Verification
    results.push({
      name: '1. Preset Visual Styles Registry Check',
      passed: PRESET_VISUAL_STYLES.length === 8,
      details: `พบสไตล์เริ่มต้นครบถ้วน ${PRESET_VISUAL_STYLES.length}/8 สไตล์`
    });

    // Test 2: Thin Single-Line Character Rule Enforcement
    const classicStyle = PRESET_VISUAL_STYLES.find(s => s.id === 'classic-stickman');
    const hasThinRule = classicStyle && classicStyle.characterRules.includes('Single-line stroke');
    results.push({
      name: '2. Thin Single-Line Limbs Rule Enforcement',
      passed: hasThinRule,
      details: hasThinRule ? 'ตรวจสอบกฎแขนขาเส้นเดี่ยว (2px) สำหรับ Classic & Cinematic Stickman เรียบร้อย' : 'ไม่พบกฎแขนขาเส้นเดี่ยว'
    });

    // Test 3: LocalStorage Project Data Persistence
    const savedProjects = localStorage.getItem('ton_studio_projects');
    results.push({
      name: '3. Project Data & Style Persistence Check',
      passed: !!savedProjects,
      details: savedProjects ? 'พบระบบจัดเก็บข้อมูลใน LocalStorage พร้อมกู้คืน visualStyleId และ previews' : 'ไม่พบข้อมูลใน LocalStorage'
    });

    // Test 4: Custom Styles Persistence
    results.push({
      name: '4. Custom Style Creator Storage Check',
      passed: true,
      details: `สไตล์คัสตอมปัจจุบันถูกลงทะเบียนไว้ ${customStyles.length} สไตล์`
    });

    // Test 5: API Key Configuration
    results.push({
      name: '5. Gemini 3.1 Flash Image Engine Status',
      passed: !!apiKey,
      details: apiKey ? 'ตั้งค่า API Key แล้ว พร้อมสำหรับ Live Preview Generation' : 'ยังไม่ได้ระบุ API Key (ต้องตั้งค่าในเมนูตั้งค่า)'
    });

    setTestResults(results);
    showToast('รันการตรวจสอบระบบเรียบร้อยแล้ว!');
  };

  // ==========================================
  // RENDER UI VIEWS
  // ==========================================
  return (
    <div className="min-h-screen bg-[#07090e] text-slate-100 font-sans flex flex-col selection:bg-cyan-500 selection:text-black">
      
      {/* GLOBAL HEADER */}
      <header className="h-16 border-b border-slate-800 bg-[#0f131c]/90 backdrop-blur-md sticky top-0 z-40 px-4 flex items-center justify-between">
        <div className="flex items-center space-x-3 cursor-pointer" onClick={() => setCurrentView('dashboard')}>
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500 via-blue-600 to-violet-600 p-0.5 flex items-center justify-center shadow-lg shadow-cyan-500/20">
            <div className="w-full h-full bg-[#090d16] rounded-[10px] flex items-center justify-center">
              <Clapperboard className="w-5 h-5 text-cyan-400" />
            </div>
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="font-extrabold tracking-wider bg-gradient-to-r from-cyan-400 via-blue-400 to-indigo-300 bg-clip-text text-transparent text-lg">
                TON STICKMAN STUDIO
              </span>
              <span className="text-[10px] font-semibold bg-cyan-950 text-cyan-400 border border-cyan-800 px-2 py-0.5 rounded-full">
                THAI PRO v3.1
              </span>
            </div>
            <p className="text-[11px] text-slate-400 hidden sm:block">ระบบสร้างภาพยนตร์สติกแมนระดับมืออาชีพ</p>
          </div>
        </div>

        {/* Top Header Controls */}
        <div className="flex items-center space-x-3">
          {/* Active project badge */}
          {activeProject && currentView === 'workbench' && (
            <div className="hidden md:flex items-center space-x-2 bg-slate-900/80 border border-slate-700/60 px-3 py-1.5 rounded-lg text-xs">
              <Film className="w-3.5 h-3.5 text-cyan-400" />
              <span className="text-slate-300 font-medium truncate max-w-[180px]">{activeProject.title}</span>
              <span className="text-[10px] bg-slate-800 text-slate-400 px-1.5 py-0.5 rounded">
                {activeProject.visualStyleName}
              </span>
            </div>
          )}

          {/* API Key Status Indicator */}
          <button 
            onClick={() => setCurrentView('settings')}
            className={`flex items-center space-x-1.5 text-xs px-3 py-1.5 rounded-lg border transition-all ${
              apiKey 
                ? 'bg-emerald-950/40 border-emerald-700/50 text-emerald-300 hover:bg-emerald-900/40' 
                : 'bg-amber-950/40 border-amber-700/50 text-amber-300 hover:bg-amber-900/40 animate-pulse'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>{apiKey ? 'Gemini API พร้อมใช้งาน' : 'ตั้งค่า API Key'}</span>
          </button>

          {/* New Project Button */}
          <button 
            onClick={() => {
              setWizardStep(1);
              setCurrentView('wizard');
            }}
            className="flex items-center space-x-1.5 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs px-3.5 py-2 rounded-lg shadow-md transition-all active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span className="hidden sm:inline">สร้างภาพยนตร์ใหม่</span>
          </button>
        </div>
      </header>

      {/* MAIN CONTAINER */}
      <div className="flex-1 flex overflow-hidden">
        
        {/* DESKTOP SIDEBAR NAVIGATION (IF IN WORKBENCH) */}
        {currentView === 'workbench' && (
          <aside className="w-64 border-r border-slate-800 bg-[#0b0e17] flex flex-col justify-between hidden lg:flex">
            <div className="p-3 space-y-1">
              <div className="px-3 py-2 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                ขั้นตอนการผลิตภาพยนตร์
              </div>

              {[
                { id: 'overview', label: 'ภาพรวม & ตั้งค่าภาพยนตร์', icon: Film },
                { id: 'style', label: 'คลังสไตล์ & พรีวิวภาพ', icon: Palette, highlight: true },
                { id: 'screenplay', label: 'AI Story & บทภาพยนตร์', icon: FileText },
                { id: 'characters', label: 'Character Studio (คลังตัวละคร)', icon: Users },
                { id: 'storyboard', label: 'Storyboard Studio (สตอรี่บอร์ด)', icon: Layers },
                { id: 'images', label: 'Image Studio (เจนภาพฉาก)', icon: ImageIcon },
                { id: 'prompt17', label: '17-Point Production Engine', icon: Wand2 },
                { id: 'voice', label: 'Voice Studio (เสียงพากย์ TTS)', icon: Volume2 },
                { id: 'music', label: 'Music & Sound Studio (เพลงประกอบ)', icon: Music },
                { id: 'render', label: 'Render Queue & สรุปภาพยนตร์', icon: Video },
                { id: 'diagnostics', label: 'ตรวจสอบระบบ Diagnostics', icon: Terminal }
              ].map(item => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => setActiveTab(item.id)}
                    className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-medium transition-all ${
                      isActive 
                        ? 'bg-gradient-to-r from-cyan-950/80 to-slate-900 border border-cyan-700/60 text-cyan-300 font-semibold shadow-inner' 
                        : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/50'
                    }`}
                  >
                    <div className="flex items-center space-x-2.5">
                      <Icon className={`w-4 h-4 ${isActive ? 'text-cyan-400' : 'text-slate-500'}`} />
                      <span>{item.label}</span>
                    </div>
                    {item.highlight && (
                      <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
                    )}
                  </button>
                );
              })}
            </div>

            {/* Current Project Info Footer */}
            <div className="p-3 border-t border-slate-800/80 bg-slate-950/50 text-xs">
              <div className="text-[11px] text-slate-500 mb-1">สไตล์ภาพยนตร์ปัจจุบัน:</div>
              <div className="font-medium text-slate-200 truncate">{activeProject?.visualStyleName}</div>
              <div className="text-[10px] text-cyan-400/80 mt-1 flex items-center space-x-1">
                <span>อัตราส่วน: {activeProject?.aspectRatio}</span>
                <span>•</span>
                <span>{activeProject?.resolution}</span>
              </div>
            </div>
          </aside>
        )}

        {/* CONTENT AREA */}
        <main className="flex-1 overflow-y-auto bg-[#07090e] p-4 md:p-6">
          
          {/* VIEW 1: DASHBOARD / PROJECT SELECTOR */}
          {currentView === 'dashboard' && (
            <div className="max-w-6xl mx-auto space-y-6">
              
              {/* Hero Banner */}
              <div className="relative rounded-2xl bg-gradient-to-r from-cyan-950/60 via-slate-900 to-indigo-950/60 border border-cyan-800/40 p-6 md:p-8 overflow-hidden shadow-2xl">
                <div className="absolute -right-10 -bottom-10 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
                <div className="relative z-10 max-w-2xl space-y-3">
                  <span className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-xs font-semibold">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Gemini 3.1 Flash Image Engine Inside</span>
                  </span>
                  <h1 className="text-2xl md:text-4xl font-extrabold text-white tracking-tight">
                    สร้างภาพยนตร์สติกแมนระดับโพร ด้วยพลัง AI สมบูรณ์แบบ
                  </h1>
                  <p className="text-sm text-slate-300 leading-relaxed">
                    ระบบสตูดิโอภาพยนตร์ Stickman แบบจบในที่เดียว รองรับคลังสไตล์ visual art 8 รูปแบบ พร้อมระบบ Live Preview เจนเนอเรตภาพจริง และครอบคลุมสายการผลิตตั้งแต่บทภาพยนตร์ สตอรี่บอร์ด เสียงพากย์ จนถึงเรนเดอร์
                  </p>

                  <div className="pt-2 flex flex-wrap gap-3">
                    <button 
                      onClick={() => {
                        setWizardStep(1);
                        setCurrentView('wizard');
                      }}
                      className="bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-bold px-5 py-2.5 rounded-xl shadow-lg shadow-cyan-500/20 text-xs flex items-center space-x-2 transition-all active:scale-95"
                    >
                      <Plus className="w-4 h-4" />
                      <span>เริ่มสร้างโปรเจกต์ใหม่</span>
                    </button>

                    <button 
                      onClick={runSystemDiagnostics}
                      className="bg-slate-800/80 hover:bg-slate-800 text-slate-200 border border-slate-700 font-semibold px-4 py-2.5 rounded-xl text-xs flex items-center space-x-2 transition-all"
                    >
                      <Terminal className="w-4 h-4 text-cyan-400" />
                      <span>ตรวจสอบระบบ (Diagnostics)</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Projects List Section */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h2 className="text-lg font-bold text-slate-100 flex items-center space-x-2">
                    <Film className="w-5 h-5 text-cyan-400" />
                    <span>ภาพยนตร์ของคุณ ({projects.length})</span>
                  </h2>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {projects.map(proj => {
                    const styleObj = allAvailableStyles.find(s => s.id === proj.visualStyleId);
                    return (
                      <div 
                        key={proj.id}
                        className="group bg-[#0f131c] border border-slate-800 hover:border-cyan-600/60 rounded-2xl p-4 transition-all duration-300 hover:shadow-xl hover:shadow-cyan-950/40 flex flex-col justify-between"
                      >
                        <div className="space-y-3">
                          {/* Thumbnail or Style Art */}
                          <div className="w-full h-36 rounded-xl bg-slate-900 border border-slate-800 overflow-hidden relative">
                            {proj.generatedStylePreview ? (
                              <img src={proj.generatedStylePreview} alt={proj.title} className="w-full h-full object-cover" />
                            ) : (
                              <BespokeStyleThumb styleId={proj.visualStyleId} />
                            )}
                            <div className="absolute top-2 right-2 bg-slate-950/80 backdrop-blur border border-slate-700 text-[10px] text-cyan-300 px-2 py-0.5 rounded-full">
                              {proj.aspectRatio} • {proj.resolution}
                            </div>
                          </div>

                          <div>
                            <span className="text-[10px] font-semibold text-cyan-400 uppercase tracking-wider">
                              {proj.visualStyleName}
                            </span>
                            <h3 className="font-bold text-slate-100 text-base line-clamp-1 group-hover:text-cyan-300 transition-colors">
                              {proj.title}
                            </h3>
                            <p className="text-xs text-slate-400 line-clamp-2 mt-1">
                              {proj.scriptConcept}
                            </p>
                          </div>
                        </div>

                        <div className="pt-4 mt-4 border-t border-slate-800/80 flex items-center justify-between text-xs">
                          <span className="text-slate-500 text-[11px]">
                            แก้ไขเมื่อ: {new Date(proj.updatedAt).toLocaleDateString('th-TH')}
                          </span>

                          <button 
                            onClick={() => {
                              setActiveProjectId(proj.id);
                              setCurrentView('workbench');
                              setActiveTab('overview');
                            }}
                            className="bg-slate-800 hover:bg-cyan-600 hover:text-slate-950 text-slate-200 px-3 py-1.5 rounded-lg font-semibold flex items-center space-x-1 transition-all"
                          >
                            <span>เปิดห้องตัดต่อ</span>
                            <ChevronRight className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* VIEW 2: CREATE NEW PROJECT WIZARD */}
          {currentView === 'wizard' && (
            <div className="max-w-5xl mx-auto space-y-6">
              
              {/* Wizard Steps Header */}
              <div className="bg-[#0f131c] border border-slate-800 rounded-2xl p-4 flex items-center justify-between">
                <div>
                  <h2 className="text-lg font-extrabold text-white">สร้างภาพยนตร์สติกแมนเรื่องใหม่</h2>
                  <p className="text-xs text-slate-400">กำหนดรายละเอียด อัตราส่วนสัดส่วนภาพ และเลือกสไตล์ที่ต้องการ</p>
                </div>

                <div className="flex items-center space-x-2 text-xs">
                  {[1, 2, 3].map(stepNum => (
                    <div 
                      key={stepNum} 
                      className={`flex items-center justify-center w-7 h-7 rounded-full font-bold transition-all ${
                        wizardStep === stepNum 
                          ? 'bg-cyan-400 text-slate-950 shadow-md shadow-cyan-500/20' 
                          : wizardStep > stepNum 
                            ? 'bg-cyan-950 text-cyan-400 border border-cyan-700' 
                            : 'bg-slate-800 text-slate-500'
                      }`}
                    >
                      {stepNum}
                    </div>
                  ))}
                </div>
              </div>

              {/* STEP 1: BASIC INFO & ASPECT RATIO */}
              {wizardStep === 1 && (
                <div className="bg-[#0f131c] border border-slate-800 rounded-2xl p-6 space-y-6">
                  <div className="space-y-2">
                    <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider">
                      ชื่อเรื่องภาพยนตร์ (Movie Title) *
                    </label>
                    <input 
                      type="text"
                      value={wizardData.title}
                      onChange={(e) => setWizardData({ ...wizardData, title: e.target.value })}
                      placeholder="เช่น TON : ศึกมหาสงครามสติกแมนแห่งอนาคต..."
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-cyan-500"
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {/* Aspect Ratio */}
                    <div className="space-y-2">
                      <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider">
                        อัตราส่วนสัดส่วนภาพ (Aspect Ratio)
                      </label>
                      <div className="grid grid-cols-3 gap-2">
                        {[
                          { id: '16:9', label: '16:9 Cinema', icon: Monitor },
                          { id: '9:16', label: '9:16 Short', icon: Smartphone },
                          { id: '1:1', label: '1:1 Square', icon: Square }
                        ].map(opt => {
                          const Icon = opt.icon;
                          const selected = wizardData.aspectRatio === opt.id;
                          return (
                            <button
                              key={opt.id}
                              onClick={() => setWizardData({ ...wizardData, aspectRatio: opt.id })}
                              className={`p-3 rounded-xl border text-center flex flex-col items-center justify-center space-y-1 transition-all ${
                                selected 
                                  ? 'bg-cyan-950/80 border-cyan-500 text-cyan-300 font-bold' 
                                  : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'
                              }`}
                            >
                              <Icon className="w-5 h-5" />
                              <span className="text-[11px]">{opt.label}</span>
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    {/* Resolution */}
                    <div className="space-y-2">
                      <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider">
                        ความละเอียดวิดีโอ (Resolution)
                      </label>
                      <select
                        value={wizardData.resolution}
                        onChange={(e) => setWizardData({ ...wizardData, resolution: e.target.value })}
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-cyan-500"
                      >
                        <option value="1080p (Full HD)">1080p Full HD (1920x1080)</option>
                        <option value="4K (Ultra HD)">4K Ultra HD (3840x2160)</option>
                        <option value="720p (HD Short)">720p HD (1280x720)</option>
                      </select>
                    </div>

                    {/* Language */}
                    <div className="space-y-2">
                      <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider">
                        ภาษาของภาพยนตร์ (Movie Language)
                      </label>
                      <select
                        value={wizardData.movieLanguage}
                        onChange={(e) => setWizardData({ ...wizardData, movieLanguage: e.target.value })}
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-cyan-500"
                      >
                        <option value="th">ภาษาไทย (Thai Pro)</option>
                        <option value="en">English (Global)</option>
                        <option value="lo">ภาษาลาว (Lao)</option>
                      </select>
                    </div>
                  </div>

                  <div className="flex justify-end pt-4 border-t border-slate-800">
                    <button
                      onClick={() => {
                        if (!wizardData.title.trim()) {
                          showToast('กรุณาระบุชื่อเรื่องภาพยนตร์ก่อนทำขั้นตอนถัดไป', 'error');
                          return;
                        }
                        setWizardStep(2);
                      }}
                      className="bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-bold px-6 py-2.5 rounded-xl text-xs flex items-center space-x-2 shadow-md"
                    >
                      <span>ถัดไป: เลือกสไตล์ภาพยนตร์</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              )}

              {/* STEP 2: VISUAL STYLE GALLERY & CUSTOM CREATOR */}
              {wizardStep === 2 && (
                <div className="space-y-6">
                  
                  {/* Gallery category filters */}
                  <div className="bg-[#0f131c] border border-slate-800 rounded-2xl p-4 space-y-3">
                    <div className="flex flex-wrap items-center justify-between gap-3">
                      <div>
                        <h3 className="text-sm font-bold text-white">คลังสไตล์ภาพยนตร์ (Visual Style Gallery)</h3>
                        <p className="text-[11px] text-slate-400 mt-1">เลือกหมวดก่อน แล้วดูภาพตัวอย่างของแต่ละสไตล์</p>
                      </div>
                      <button
                        onClick={() => setPreviewModalStyle(allAvailableStyles.find(s => s.id === wizardData.visualStyleId))}
                        className="text-xs text-cyan-400 hover:text-cyan-300 underline font-medium flex items-center space-x-1"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>ดูสไตล์ที่เลือก</span>
                      </button>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {STYLE_CATEGORY_LABELS.map(category => (
                        <button key={category.id} onClick={() => setWizardStyleFilter(category.id)}
                          className={`px-3 py-2 rounded-lg text-xs font-bold border transition-all ${wizardStyleFilter === category.id ? 'bg-cyan-400 text-slate-950 border-cyan-300' : 'bg-slate-900 text-slate-300 border-slate-700 hover:border-cyan-600'}`}>
                          {category.label}
                          {category.id === 'stickman' && <span className="ml-1 opacity-70">({allAvailableStyles.filter(s => s.category === 'stickman').length})</span>}
                        </button>
                      ))}
                      <button onClick={() => setWizardStyleFilter('custom')} className={`px-3 py-2 rounded-lg text-xs font-bold border ${wizardStyleFilter === 'custom' ? 'bg-cyan-400 text-slate-950 border-cyan-300' : 'bg-slate-900 text-slate-300 border-slate-700'}`}>Custom</button>
                    </div>
                  </div>

                  {/* Preset Styles Grid */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    {wizardFilteredStyles.length === 0 && <div className="col-span-full rounded-xl border border-dashed border-slate-700 p-8 text-center text-xs text-slate-400">ยังไม่มีสไตล์ในหมวดนี้ กรุณาเพิ่มสไตล์คัสตอม หรือเลือกหมวดอื่น</div>}
                    {wizardFilteredStyles.map(style => {
                      const isSelected = wizardData.visualStyleId === style.id;
                      return (
                        <div
                          key={style.id}
                          className={`relative rounded-2xl border p-3 flex flex-col justify-between transition-all duration-200 cursor-pointer ${
                            isSelected 
                              ? 'bg-cyan-950/40 border-cyan-400 shadow-xl shadow-cyan-950/50 ring-1 ring-cyan-400' 
                              : 'bg-[#0f131c] border-slate-800 hover:border-slate-700'
                          }`}
                          onClick={() => setWizardData({ ...wizardData, visualStyleId: style.id })}
                        >
                          {/* Active Badge */}
                          {isSelected && (
                            <div className="absolute top-2 right-2 bg-cyan-400 text-slate-950 font-bold text-[10px] px-2 py-0.5 rounded-full flex items-center space-x-1 z-10 shadow">
                              <Check className="w-3 h-3" />
                              <span>เลือกอยู่</span>
                            </div>
                          )}

                          <div className="space-y-2">
                            {/* SVG Thumbnail */}
                            <div className="w-full h-32 rounded-xl bg-slate-950 border border-slate-800 overflow-hidden relative">
                              {style.refImage ? (
                                <img src={style.refImage} alt={style.nameTh} className="w-full h-full object-cover" />
                              ) : (
                                <BespokeStyleThumb styleId={style.id} />
                              )}
                            </div>

                            <div>
                              <span className="text-[10px] font-semibold text-cyan-400">{style.badge || 'Preset'} · {style.category === 'stickman' ? 'STICKMAN SUBSTYLE' : style.category.toUpperCase()}</span>
                              <h4 className="font-bold text-slate-100 text-sm">{style.nameTh}</h4>
                              <p className="text-[11px] text-slate-400 line-clamp-2 mt-1">{style.shortDesc}</p>
                            </div>
                          </div>

                          <div className="pt-3 mt-3 border-t border-slate-800/80 flex items-center space-x-2">
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                setPreviewModalStyle(style);
                              }}
                              className="flex-1 bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] font-semibold py-1.5 rounded-lg flex items-center justify-center space-x-1"
                            >
                              <Eye className="w-3 h-3" />
                              <span>ดูตัวอย่าง</span>
                            </button>

                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                setWizardData({ ...wizardData, visualStyleId: style.id });
                              }}
                              className={`flex-1 text-[11px] font-semibold py-1.5 rounded-lg flex items-center justify-center space-x-1 transition-all ${
                                isSelected 
                                  ? 'bg-cyan-400 text-slate-950 font-bold' 
                                  : 'bg-slate-900 hover:bg-cyan-950 hover:text-cyan-300 text-slate-300 border border-slate-800'
                              }`}
                            >
                              <span>{isSelected ? 'เลือกแล้ว' : 'เลือกสไตล์นี้'}</span>
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  {/* CUSTOM STYLE CREATOR SECTION */}
                  <div className="bg-[#0f131c] border border-slate-800 rounded-2xl p-6 space-y-4">
                    <h3 className="text-sm font-bold text-slate-200 flex items-center space-x-2">
                      <Wand2 className="w-4 h-4 text-cyan-400" />
                      <span>สร้างสไตล์ของฉัน (Create Custom Style Builder)</span>
                    </h3>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-3">
                        <input
                          type="text"
                          placeholder="ชื่อสไตล์ (ภาษาไทย)..."
                          value={customStyleForm.nameTh}
                          onChange={(e) => setCustomStyleForm({ ...customStyleForm, nameTh: e.target.value })}
                          className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                        />
                        <textarea
                          placeholder="พรอมต์กำหนดสไตล์ (Style Prompt Tokens in English)..."
                          rows={3}
                          value={customStyleForm.promptTokens}
                          onChange={(e) => setCustomStyleForm({ ...customStyleForm, promptTokens: e.target.value })}
                          className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                        />
                      </div>

                      <div className="space-y-3">
                        <div className="flex items-center space-x-3">
                          <label className="cursor-pointer bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 px-3 py-2 rounded-xl text-xs flex items-center space-x-2">
                            <Upload className="w-4 h-4 text-cyan-400" />
                            <span>อัปโหลดภาพอ้างอิง</span>
                            <input type="file" accept="image/*" className="hidden" onChange={handleCustomRefImageUpload} />
                          </label>
                          {customStyleForm.refImage && (
                            <span className="text-xs text-emerald-400 font-medium">✓ อัปโหลดรูปอ้างอิงแล้ว</span>
                          )}
                        </div>

                        <button
                          onClick={handleSaveCustomStyle}
                          className="w-full bg-slate-800 hover:bg-cyan-600 hover:text-slate-950 text-cyan-300 font-bold py-2 rounded-xl text-xs flex items-center justify-center space-x-2 border border-slate-700 transition-all"
                        >
                          <Save className="w-4 h-4" />
                          <span>บันทึกสไตล์คัสตอมไว้ใช้งาน</span>
                        </button>
                      </div>
                    </div>
                  </div>

                  <div className="flex justify-between pt-4">
                    <button
                      onClick={() => setWizardStep(1)}
                      className="bg-slate-800 hover:bg-slate-700 text-slate-300 px-5 py-2.5 rounded-xl text-xs font-semibold flex items-center space-x-2"
                    >
                      <ArrowLeft className="w-4 h-4" />
                      <span>ย้อนกลับ</span>
                    </button>

                    <button
                      onClick={() => setWizardStep(3)}
                      className="bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-bold px-6 py-2.5 rounded-xl text-xs flex items-center space-x-2 shadow-md"
                    >
                      <span>ถัดไป: แนวคิดเรื่อง & สร้างโปรเจกต์</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              )}

              {/* STEP 3: STORY CONCEPT & CONFIRMATION */}
              {wizardStep === 3 && (
                <div className="bg-[#0f131c] border border-slate-800 rounded-2xl p-6 space-y-6">
                  <div className="space-y-2">
                    <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider">
                      แนวคิดพล็อตเรื่องสรุป (Movie Story Concept)
                    </label>
                    <textarea
                      rows={4}
                      value={wizardData.scriptConcept}
                      onChange={(e) => setWizardData({ ...wizardData, scriptConcept: e.target.value })}
                      placeholder="อธิบายเรื่องราวย่อของภาพยนตร์สติกแมนเรื่องนี้ เช่น การต่อสู้ของ TON กับองค์กรเงามืดเพื่อแย่งชิงผลึกนีออน..."
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-cyan-500"
                    />
                  </div>

                  {/* Summary Box */}
                  <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 space-y-2 text-xs">
                    <div className="font-bold text-cyan-400">สรุปการตั้งค่าโปรเจกต์:</div>
                    <div className="grid grid-cols-2 gap-2 text-slate-300">
                      <div>ชื่อเรื่อง: <span className="font-semibold text-white">{wizardData.title}</span></div>
                      <div>สไตล์ที่เลือก: <span className="font-semibold text-white">{allAvailableStyles.find(s => s.id === wizardData.visualStyleId)?.nameTh}</span></div>
                      <div>อัตราส่วน: <span className="font-semibold text-white">{wizardData.aspectRatio}</span></div>
                      <div>ภาษา: <span className="font-semibold text-white">{wizardData.movieLanguage}</span></div>
                    </div>
                  </div>

                  <div className="flex justify-between pt-4 border-t border-slate-800">
                    <button
                      onClick={() => setWizardStep(2)}
                      className="bg-slate-800 hover:bg-slate-700 text-slate-300 px-5 py-2.5 rounded-xl text-xs font-semibold flex items-center space-x-2"
                    >
                      <ArrowLeft className="w-4 h-4" />
                      <span>ย้อนกลับ</span>
                    </button>

                    <button
                      onClick={handleCreateProjectFromWizard}
                      className="bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-slate-950 font-extrabold px-8 py-3 rounded-xl text-sm flex items-center space-x-2 shadow-lg shadow-cyan-500/20 transition-all active:scale-95"
                    >
                      <Sparkles className="w-5 h-5" />
                      <span>ยืนยันสร้างโปรเจกต์ & เข้าสู่ห้องตัดต่อ</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* VIEW 3: ACTIVE PROJECT WORKBENCH (12 MODULES) */}
          {currentView === 'workbench' && activeProject && (
            <div className="max-w-6xl mx-auto space-y-6">
              
              {/* Active Tab Router */}
              {activeTab === 'overview' && (
                <div className="bg-[#0f131c] border border-slate-800 rounded-2xl p-6 space-y-6">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-4">
                    <div>
                      <h2 className="text-xl font-bold text-white">{activeProject.title}</h2>
                      <p className="text-xs text-slate-400">ภาพรวมการตั้งค่าและข้อมูลโปรเจกต์ปัจจุบัน</p>
                    </div>

                    <button
                      onClick={() => setActiveTab('style')}
                      className="bg-cyan-950 border border-cyan-700 text-cyan-300 hover:bg-cyan-900 px-4 py-2 rounded-xl text-xs font-bold flex items-center space-x-2"
                    >
                      <Palette className="w-4 h-4" />
                      <span>จัดการสไตล์ภาพยนตร์</span>
                    </button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
                      <span className="text-xs text-slate-500 font-bold uppercase">สไตล์ภาพยนตร์</span>
                      <div className="text-base font-bold text-cyan-400">{activeProject.visualStyleName}</div>
                      <p className="text-xs text-slate-400">{activeProject.visualStyleDescription}</p>
                    </div>

                    <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
                      <span className="text-xs text-slate-500 font-bold uppercase">ความละเอียด & อัตราส่วน</span>
                      <div className="text-base font-bold text-white">{activeProject.aspectRatio}</div>
                      <div className="text-xs text-slate-400">{activeProject.resolution}</div>
                    </div>

                    <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
                      <span className="text-xs text-slate-500 font-bold uppercase">ภาษา & ความยาว</span>
                      <div className="text-base font-bold text-white">ภาษาไทย (TH Pro)</div>
                      <div className="text-xs text-slate-400">เป้าหมายความยาว ~{activeProject.targetDurationMinutes} นาที</div>
                    </div>
                  </div>

                  {/* Active Preview Display */}
                  <div className="space-y-2">
                    <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">ภาพพรีวิวสไตล์หลักประจำเรื่อง</h3>
                    <div className="w-full h-64 rounded-2xl bg-slate-900 border border-slate-800 overflow-hidden relative flex items-center justify-center">
                      {activeProject.generatedStylePreview ? (
                        <img src={activeProject.generatedStylePreview} alt="Project Preview" className="w-full h-full object-cover" />
                      ) : (
                        <BespokeStyleThumb styleId={activeProject.visualStyleId} />
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* TAB: VISUAL STYLE GALLERY & CHANGE MANAGER */}
              {activeTab === 'style' && (
                <div className="space-y-6">
                  <div className="bg-[#0f131c] border border-slate-800 rounded-2xl p-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                    <div>
                      <h2 className="text-lg font-bold text-white flex items-center space-x-2">
                        <Palette className="w-5 h-5 text-cyan-400" />
                        <span>คลังสไตล์ภาพยนตร์ & ระบบเปลี่ยนสไตล์ (Style Gallery)</span>
                      </h2>
                      <p className="text-xs text-slate-400 mt-1">
                        สไตล์ปัจจุบัน: <span className="font-bold text-cyan-300">{activeProject.visualStyleName}</span> · <span className="text-emerald-400">{activeProject.styleLocked !== false ? 'Style Lock เปิดอยู่' : 'Style Lock ปิดอยู่'}</span>
                      </p>
                    </div>

                    <div className="flex flex-wrap gap-2">
                      <button
                        onClick={() => setProjects(projects.map(p => p.id === activeProject.id ? { ...p, styleLocked: p.styleLocked === false } : p))}
                        className={`px-3 py-2 rounded-xl text-xs font-bold border flex items-center gap-2 ${activeProject.styleLocked !== false ? 'bg-emerald-950/50 border-emerald-700 text-emerald-300' : 'bg-slate-900 border-slate-700 text-slate-300'}`}
                      >
                        <Lock className="w-4 h-4" />
                        {activeProject.styleLocked !== false ? 'Style Lock: ON' : 'Style Lock: OFF'}
                      </button>
                      <button
                        onClick={() => setPreviewModalStyle(allAvailableStyles.find(s => s.id === activeProject.visualStyleId))}
                        className="bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-bold px-4 py-2 rounded-xl text-xs flex items-center space-x-2 shadow"
                      >
                        <Eye className="w-4 h-4" />
                        <span>ทดลองสร้างภาพพรีวิวไลฟ์ (Gemini 3.1)</span>
                      </button>
                    </div>
                  </div>

                  {/* Style category filters */}
                  <div className="bg-[#0f131c] border border-slate-800 rounded-2xl p-4 space-y-3">
                    <div className="text-sm font-bold text-white">เลือกหมวดสไตล์</div>
                    <div className="flex flex-wrap gap-2">
                      {STYLE_CATEGORY_LABELS.map(category => (
                        <button key={category.id} onClick={() => setWorkbenchStyleFilter(category.id)}
                          className={`px-3 py-2 rounded-lg text-xs font-bold border transition-all ${workbenchStyleFilter === category.id ? 'bg-cyan-400 text-slate-950 border-cyan-300' : 'bg-slate-900 text-slate-300 border-slate-700 hover:border-cyan-600'}`}>
                          {category.label}
                        </button>
                      ))}
                      <button onClick={() => setWorkbenchStyleFilter('custom')} className={`px-3 py-2 rounded-lg text-xs font-bold border ${workbenchStyleFilter === 'custom' ? 'bg-cyan-400 text-slate-950 border-cyan-300' : 'bg-slate-900 text-slate-300 border-slate-700'}`}>Custom</button>
                    </div>
                  </div>

                  {/* Styles Grid */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    {workbenchFilteredStyles.length === 0 && <div className="col-span-full rounded-xl border border-dashed border-slate-700 p-8 text-center text-xs text-slate-400">ยังไม่มีสไตล์ในหมวดนี้</div>}
                    {workbenchFilteredStyles.map(style => {
                      const isCurrent = activeProject.visualStyleId === style.id;
                      return (
                        <div
                          key={style.id}
                          className={`rounded-2xl border p-4 flex flex-col justify-between transition-all duration-200 ${
                            isCurrent 
                              ? 'bg-cyan-950/40 border-cyan-400 ring-1 ring-cyan-400 shadow-lg' 
                              : 'bg-[#0f131c] border-slate-800 hover:border-slate-700'
                          }`}
                        >
                          <div className="space-y-3">
                            <div className="w-full h-32 rounded-xl bg-slate-950 border border-slate-800 overflow-hidden relative">
                              {style.refImage ? (
                                <img src={style.refImage} alt={style.nameTh} className="w-full h-full object-cover" />
                              ) : (
                                <BespokeStyleThumb styleId={style.id} />
                              )}
                            </div>

                            <div>
                              <div className="flex items-center justify-between">
                                <span className="text-[10px] font-bold text-cyan-400 uppercase">{style.badge || 'Preset'}</span>
                                {isCurrent && (
                                  <span className="text-[10px] bg-cyan-400 text-slate-950 font-extrabold px-2 py-0.5 rounded-full">ใช้งานอยู่</span>
                                )}
                              </div>
                              <h3 className="font-bold text-slate-100 text-sm mt-0.5">{style.nameTh}</h3>
                              <p className="text-[11px] text-slate-400 line-clamp-2 mt-1">{style.shortDesc}</p>
                            </div>
                          </div>

                          <div className="pt-3 mt-3 border-t border-slate-800 flex items-center space-x-2">
                            <button
                              onClick={() => setPreviewModalStyle(style)}
                              className="flex-1 bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] font-semibold py-1.5 rounded-lg flex items-center justify-center space-x-1"
                            >
                              <Eye className="w-3.5 h-3.5" />
                              <span>ดูตัวอย่าง</span>
                            </button>

                            {!isCurrent && (
                              <button
                                onClick={() => handleApplyStyleToActiveProject(style)}
                                className="flex-1 bg-slate-900 hover:bg-cyan-950 hover:text-cyan-300 border border-slate-700 text-slate-300 text-[11px] font-bold py-1.5 rounded-lg flex items-center justify-center space-x-1"
                              >
                                <span>เปลี่ยนสไตล์</span>
                              </button>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* TAB: SCREENPLAY & AI STORY WRITER */}
              {activeTab === 'screenplay' && (
                <div className="bg-[#0f131c] border border-slate-800 rounded-2xl p-6 space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h2 className="text-lg font-bold text-white">AI Story Writer & Screenplay Generator</h2>
                      <p className="text-xs text-slate-400">สร้างและแก้ไขบทภาพยนตร์ที่ผสานสไตล์ {activeProject.visualStyleName}</p>
                    </div>

                    <button
                      onClick={async () => {
                        if (!apiKey) {
                          showToast('กรุณากรอก Gemini API Key ในเมนูตั้งค่าก่อน', 'error');
                          return;
                        }
                        showToast('กำลังร่างบทภาพยนตร์ด้วย Gemini 3 Flash...');
                        try {
                          const res = await callGeminiTextAPI({
                            systemPrompt: `Act as a world-class stickman anime screenplay writer. Generate a script structured by scenes for style: ${activeProject.visualStyleName}. Maintain thin single-line limbs rule for character descriptions.`,
                            userPrompt: `Write a 3-scene screenplay for: ${activeProject.scriptConcept}`
                          });
                          if (res) {
                            setProjects(projects.map(p => p.id === activeProject.id ? { ...p, screenplay: res } : p));
                            showToast('สร้างบทภาพยนตร์เรียบร้อยแล้ว!');
                          }
                        } catch (e) {
                          showToast(e.message, 'error');
                        }
                      }}
                      className="bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-bold px-4 py-2 rounded-xl text-xs flex items-center space-x-2"
                    >
                      <Sparkles className="w-4 h-4" />
                      <span>สร้างบทภาพยนตร์ด้วย AI</span>
                    </button>
                  </div>

                  <textarea
                    rows={12}
                    value={activeProject.screenplay}
                    onChange={(e) => {
                      const updatedScript = e.target.value;
                      setProjects(projects.map(p => p.id === activeProject.id ? { ...p, screenplay: updatedScript } : p));
                    }}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl p-4 text-xs font-mono text-slate-200 focus:outline-none focus:border-cyan-500"
                  />
                </div>
              )}

              {/* TAB: CHARACTER STUDIO */}
              {activeTab === 'characters' && (
                <div className="bg-[#0f131c] border border-slate-800 rounded-2xl p-6 space-y-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <h2 className="text-lg font-bold text-white">Character Studio (คลังกำหนดตัวละคร)</h2>
                      <p className="text-xs text-slate-400">ควบคุมกฎสัดส่วนตัวละครให้สอดคล้องกับ {activeProject.visualStyleName}</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {activeProject.characters.map((char, idx) => (
                      <div key={idx} className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-cyan-300 text-sm">{char.name}</span>
                          <span className="text-[10px] bg-slate-800 text-slate-400 px-2 py-0.5 rounded-full">{char.role}</span>
                        </div>
                        <p className="text-xs text-slate-300">{char.desc}</p>
                        <div className="p-2 rounded bg-slate-950 text-[11px] text-amber-300 border border-amber-900/40">
                          <strong>กฎรูปลักษณ์:</strong> {char.rules}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB: STORYBOARD STUDIO */}
              {activeTab === 'storyboard' && (
                <div className="bg-[#0f131c] border border-slate-800 rounded-2xl p-6 space-y-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <h2 className="text-lg font-bold text-white">Storyboard Studio (สตอรี่บอร์ด)</h2>
                      <p className="text-xs text-slate-400">จัดการฉากต่อฉากในการสร้างภาพยนตร์</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {activeProject.storyboards.map((sb, idx) => (
                      <div key={idx} className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-3">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-cyan-400">ฉากที่ {sb.scene}: {sb.title}</span>
                        </div>
                        <div className="w-full h-32 rounded-lg bg-slate-950 overflow-hidden flex items-center justify-center">
                          {sb.image ? (
                            <img src={sb.image} alt={sb.title} className="w-full h-full object-cover" />
                          ) : (
                            <BespokeStyleThumb styleId={activeProject.visualStyleId} />
                          )}
                        </div>
                        <p className="text-[11px] text-slate-400 line-clamp-2">{sb.prompt}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB: IMAGE GENERATION STUDIO (GEMINI 3.1 FLASH IMAGE) */}
              {activeTab === 'images' && (
                <div className="bg-[#0f131c] border border-slate-800 rounded-2xl p-6 space-y-6">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-4">
                    <div>
                      <h2 className="text-lg font-bold text-white flex items-center space-x-2">
                        <ImageIcon className="w-5 h-5 text-cyan-400" />
                        <span>Image Generation Studio (Gemini 3.1 Flash Image)</span>
                      </h2>
                      <p className="text-xs text-slate-400">สร้างภาพฉากภาพยนตร์ด้วยโมเดล Gemini Flash Image ตามสไตล์ที่เลือก</p>
                    </div>
                  </div>

                  <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-3">
                    <label className="block text-xs font-bold text-slate-300">พรอมต์ภาพฉาก (Scene Image Prompt):</label>
                    <textarea 
                      rows={3}
                      defaultValue={DEFAULT_BENCHMARK_PROMPT}
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-xs text-white"
                    />

                    <div className="flex justify-end">
                      <button
                        onClick={async () => {
                          if (!apiKey) {
                            showToast('กรุณากรอก Gemini API Key ในเมนูตั้งค่าก่อน', 'error');
                            return;
                          }
                          showToast('กำลังสร้างภาพฉากด้วย Gemini 3.1 Flash Image...');
                          try {
                            const generated = await callGeminiImageAPI({
                              prompt: DEFAULT_BENCHMARK_PROMPT,
                              stylePrompt: activeProject.visualStylePrompt,
                              aspectRatio: activeProject.aspectRatio
                            });
                            setProjects(projects.map(p => p.id === activeProject.id ? { ...p, generatedStylePreview: generated } : p));
                            showToast('สร้างภาพฉากสำเร็จ!');
                          } catch (err) {
                            showToast(err.message, 'error');
                          }
                        }}
                        className="bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-bold px-4 py-2 rounded-xl text-xs flex items-center space-x-2"
                      >
                        <Wand2 className="w-4 h-4" />
                        <span>สร้างภาพฉากด้วย Gemini 3.1 Flash Image</span>
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB: 17-POINT PROMPT ENGINE */}
              {activeTab === 'prompt17' && (
                <div className="bg-[#0f131c] border border-slate-800 rounded-2xl p-6 space-y-4">
                  <h2 className="text-lg font-bold text-white">17-Point Video Production Prompt Engine</h2>
                  <p className="text-xs text-slate-400">สร้างชุดคำสั่งพรอมต์ภาพยนตร์ 17 จุดสำหรับการคุมโทนภาพยนตร์อย่างสมบูรณ์แบบ</p>
                  
                  <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 text-xs font-mono text-slate-300 space-y-2">
                    <div>1. CHARACTER_SPECS: {activeProject.visualStyleName} thin single-line limbs</div>
                    <div>2. ENVIRONMENT: Studio/Cyberpunk high contrast parallax</div>
                    <div>3. LIGHTING: Volumetric rim lighting & anamorphic lens flare</div>
                    <div>4. ASPECT_RATIO: {activeProject.aspectRatio}</div>
                    <div>5. RESOLUTION: {activeProject.resolution}</div>
                  </div>
                </div>
              )}

              {/* TAB: VOICE STUDIO (TTS) */}
              {activeTab === 'voice' && (
                <div className="bg-[#0f131c] border border-slate-800 rounded-2xl p-6 space-y-4">
                  <h2 className="text-lg font-bold text-white">Voice Studio (ระบบเสียงพากย์ TTS)</h2>
                  <p className="text-xs text-slate-400">สร้างเสียงพากย์ด้วย Gemini 2.5 Flash Preview TTS</p>

                  <div className="space-y-3">
                    {activeProject.voiceTracks.map((vt, i) => (
                      <div key={i} className="p-3 bg-slate-900 rounded-xl flex items-center justify-between text-xs">
                        <div>
                          <span className="font-bold text-cyan-400">{vt.speaker}: </span>
                          <span className="text-slate-200">"{vt.text}"</span>
                        </div>
                        <button className="bg-slate-800 hover:bg-slate-700 text-slate-200 px-3 py-1 rounded-lg">
                          ทดลองฟังเสียง
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB: MUSIC & SOUND STUDIO */}
              {activeTab === 'music' && (
                <div className="bg-[#0f131c] border border-slate-800 rounded-2xl p-6 space-y-4">
                  <h2 className="text-lg font-bold text-white">Music & Sound Studio</h2>
                  <p className="text-xs text-slate-400">จัดการเพลงประกอบและเอฟเฟกต์เสียง SFX</p>
                  <div className="p-4 bg-slate-900 rounded-xl text-xs text-cyan-300 font-mono">
                    Track: {activeProject.musicTrack}
                  </div>
                </div>
              )}

              {/* TAB: RENDER QUEUE */}
              {activeTab === 'render' && (
                <div className="bg-[#0f131c] border border-slate-800 rounded-2xl p-6 space-y-6">
                  <h2 className="text-lg font-bold text-white">Render Queue & Export ภาพยนตร์</h2>
                  <p className="text-xs text-slate-400">เรนเดอร์และส่งออกไฟล์ภาพยนตร์สำเร็จรูป</p>

                  <button 
                    onClick={() => showToast('เริ่มกระบวนการ Render ภาพยนตร์แบบจำลอง...')}
                    className="w-full bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-slate-950 font-extrabold py-3 rounded-xl text-sm flex items-center justify-center space-x-2"
                  >
                    <Clapperboard className="w-5 h-5" />
                    <span>เริ่มเรนเดอร์ภาพยนตร์เต็มเรื่อง</span>
                  </button>
                </div>
              )}

              {/* TAB: SYSTEM DIAGNOSTICS */}
              {activeTab === 'diagnostics' && (
                <div className="bg-[#0f131c] border border-slate-800 rounded-2xl p-6 space-y-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <h2 className="text-lg font-bold text-white flex items-center space-x-2">
                        <Terminal className="w-5 h-5 text-cyan-400" />
                        <span>แผงทดสอบระบบอัตโนมัติ (Automated Diagnostic Verification Panel)</span>
                      </h2>
                      <p className="text-xs text-slate-400">ตรวจสอบความถูกต้องของการเลือกสไตล์, กฎแขนขาเส้นเดี่ยว, และการบันทึกข้อมูล</p>
                    </div>

                    <button
                      onClick={runSystemDiagnostics}
                      className="bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-bold px-4 py-2 rounded-xl text-xs flex items-center space-x-2"
                    >
                      <RefreshCw className="w-4 h-4" />
                      <span>รันการตรวจสอบระบบ</span>
                    </button>
                  </div>

                  {testResults && (
                    <div className="space-y-3">
                      {testResults.map((t, idx) => (
                        <div 
                          key={idx} 
                          className={`p-4 rounded-xl border flex items-start space-x-3 text-xs ${
                            t.passed ? 'bg-emerald-950/30 border-emerald-700/50 text-emerald-300' : 'bg-rose-950/30 border-rose-700/50 text-rose-300'
                          }`}
                        >
                          {t.passed ? <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" /> : <AlertCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />}
                          <div>
                            <div className="font-bold text-sm">{t.name}</div>
                            <div className="mt-1 opacity-90">{t.details}</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

            </div>
          )}

          {/* VIEW 4: SETTINGS PAGE */}
          {currentView === 'settings' && (
            <div className="max-w-4xl mx-auto space-y-6">
              <div className="bg-[#0f131c] border border-slate-800 rounded-2xl p-6 space-y-6">
                <div>
                  <h2 className="text-xl font-bold text-white flex items-center space-x-2">
                    <Settings className="w-5 h-5 text-cyan-400" />
                    <span>การตั้งค่าระบบ & Gemini API Key (System Settings)</span>
                  </h2>
                  <p className="text-xs text-slate-400 mt-1">
                    ตั้งค่า API Key เพื่อเปิดใช้งาน Gemini 3.1 Flash Image live preview generation
                  </p>
                </div>

                <div className="rounded-2xl border border-slate-800 bg-slate-900/70 p-4 space-y-2">
                  <div className="flex items-center gap-2 text-sm font-bold">
                    <span className={`w-2.5 h-2.5 rounded-full ${apiConfigured ? 'bg-emerald-400' : 'bg-amber-400'}`} />
                    {apiStatusChecked ? (apiConfigured ? 'Gemini API เชื่อมต่อผ่านเซิร์ฟเวอร์แล้ว' : 'ยังไม่ได้ตั้งค่า Gemini API บนเซิร์ฟเวอร์') : 'กำลังตรวจสอบสถานะเซิร์ฟเวอร์…'}
                  </div>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    เพื่อความปลอดภัย API Key จะไม่ถูกเก็บในเบราว์เซอร์ ให้ผู้ดูแลเว็บไซต์กำหนดค่า GEMINI_API_KEY ใน Environment Variables ของโฮสต์ (เช่น Render) แล้วรีสตาร์ตบริการ
                  </p>
                  <div className="text-[11px] text-slate-500 font-mono">Environment variable: GEMINI_API_KEY</div>
                </div>

                <div className="pt-4 border-t border-slate-800 flex justify-end">
                  <button onClick={() => fetch('/api/status').then(r => r.json()).then(d => { setApiConfigured(Boolean(d.geminiConfigured)); setApiStatusChecked(true); showToast(d.geminiConfigured ? 'เซิร์ฟเวอร์พร้อมใช้งาน' : 'ยังไม่พบ GEMINI_API_KEY', d.geminiConfigured ? 'success' : 'error'); }).catch(() => showToast('ติดต่อเซิร์ฟเวอร์ไม่ได้', 'error'))}
                    className="bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-bold px-6 py-2.5 rounded-xl text-xs flex items-center space-x-2 shadow-md">
                    <RefreshCw className="w-4 h-4" /><span>ตรวจสอบการเชื่อมต่อ</span>
                  </button>
                </div>
              </div>
            </div>
          )}

        </main>
      </div>

      {/* MOBILE BOTTOM NAVIGATION */}
      <nav className="h-16 border-t border-slate-800 bg-[#090d16] lg:hidden flex items-center justify-around px-2 z-40">
        {[
          { id: 'dashboard', label: 'หน้าหลัก', icon: Clapperboard, view: 'dashboard' },
          { id: 'wizard', label: 'สร้างใหม่', icon: Plus, view: 'wizard' },
          { id: 'workbench', label: 'สตูดิโอ', icon: Film, view: 'workbench' },
          { id: 'settings', label: 'ตั้งค่า', icon: Settings, view: 'settings' }
        ].map(nav => {
          const Icon = nav.icon;
          const isActive = currentView === nav.view;
          return (
            <button
              key={nav.id}
              onClick={() => {
                if (nav.view === 'wizard') setWizardStep(1);
                setCurrentView(nav.view);
              }}
              className={`flex flex-col items-center justify-center space-y-1 text-[10px] font-medium transition-all ${
                isActive ? 'text-cyan-400 font-bold' : 'text-slate-500 hover:text-slate-300'
              }`}
            >
              <Icon className="w-5 h-5" />
              <span>{nav.label}</span>
            </button>
          );
        })}
      </nav>

      {/* ========================================== */}
      {/* MODAL 1: DETAILED STYLE PREVIEW PANEL     */}
      {/* ========================================== */}
      {previewModalStyle && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-[#0f131c] border border-slate-800 rounded-3xl max-w-4xl w-full p-6 space-y-6 relative shadow-2xl my-8">
            {/* Close Button */}
            <button
              onClick={() => {
                setPreviewModalStyle(null);
                setPreviewLiveImage(null);
                setPreviewApiError(null);
              }}
              className="absolute top-4 right-4 text-slate-400 hover:text-white p-2 rounded-full bg-slate-900 border border-slate-800"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center space-x-3">
              <span className="text-xs font-bold bg-cyan-950 text-cyan-400 border border-cyan-800 px-3 py-1 rounded-full">
                {previewModalStyle.badge || 'Visual Style'}
              </span>
              <h2 className="text-xl font-extrabold text-white">{previewModalStyle.nameTh}</h2>
            </div>

            {/* Display Box */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              
              {/* Left Column: Artwork preview & live generator */}
              <div className="space-y-4">
                <div className="w-full h-64 rounded-2xl bg-slate-950 border border-slate-800 overflow-hidden relative flex items-center justify-center shadow-inner">
                  {isGeneratingLivePreview ? (
                    <div className="flex flex-col items-center justify-center space-y-3 p-4 text-center">
                      <RefreshCw className="w-8 h-8 text-cyan-400 animate-spin" />
                      <p className="text-xs text-cyan-300 font-bold">กำลังสร้างภาพตัวอย่างด้วย Gemini 3.1 Flash Image...</p>
                      <p className="text-[10px] text-slate-500">อัตราส่วน {activeProject ? activeProject.aspectRatio : wizardData.aspectRatio}</p>
                    </div>
                  ) : previewLiveImage ? (
                    <img src={previewLiveImage} alt="Live Gemini Generated Preview" className="w-full h-full object-cover" />
                  ) : previewModalStyle.refImage ? (
                    <img src={previewModalStyle.refImage} alt={previewModalStyle.nameTh} className="w-full h-full object-cover" />
                  ) : (
                    <BespokeStyleThumb styleId={previewModalStyle.id} />
                  )}
                </div>

                {/* API Honest Error Alert Box */}
                {previewApiError && (
                  <div className="p-4 rounded-xl bg-rose-950/50 border border-rose-800/80 text-xs text-rose-300 space-y-2">
                    <div className="font-bold flex items-center space-x-1.5">
                      <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                      <span>ไม่สามารถสร้างภาพตัวอย่างได้</span>
                    </div>
                    <p className="text-[11px] opacity-90">{previewApiError}</p>
                    <button
                      onClick={() => {
                        setPreviewModalStyle(null);
                        setCurrentView('settings');
                      }}
                      className="bg-rose-900 hover:bg-rose-800 text-white font-bold px-3 py-1.5 rounded-lg text-[11px] flex items-center space-x-1 mt-1"
                    >
                      <Settings className="w-3.5 h-3.5" />
                      <span>เปิดหน้าตั้งค่า API Key</span>
                    </button>
                  </div>
                )}

                {/* Live Preview Button */}
                <button
                  onClick={() => handleGenerateLiveStylePreview(previewModalStyle)}
                  disabled={isGeneratingLivePreview}
                  className="w-full bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-extrabold py-3 rounded-xl text-xs flex items-center justify-center space-x-2 shadow-lg shadow-cyan-500/20 transition-all disabled:opacity-50"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>ทดลองสร้างภาพตัวอย่าง (Live AI Preview)</span>
                </button>
              </div>

              {/* Right Column: Style Specifications */}
              <div className="space-y-4 text-xs">
                <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 space-y-2">
                  <span className="font-bold text-cyan-400 uppercase tracking-wider text-[10px]">คำอธิบายสไตล์</span>
                  <p className="text-slate-300 leading-relaxed">{previewModalStyle.desc}</p>
                </div>

                <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
                  <span className="font-bold text-amber-300 text-[10px] uppercase">กฎสัดส่วนตัวละคร (Character Rules)</span>
                  <p className="text-slate-300 text-[11px]">{previewModalStyle.characterRules}</p>
                </div>

                <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
                  <span className="font-bold text-cyan-300 text-[10px] uppercase">การจัดแสงและจานสี (Color Palette Swatches)</span>
                  <div className="flex items-center space-x-2 pt-1">
                    {previewModalStyle.colorSwatches?.map((c, i) => (
                      <div key={i} className="w-6 h-6 rounded-full border border-slate-700 shadow" style={{ backgroundColor: c }} title={c} />
                    ))}
                  </div>
                </div>

                {/* Prompt Tokens */}
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                  <span className="font-bold text-slate-400 text-[10px] uppercase">Style Prompt Tokens (English)</span>
                  <p className="text-[11px] font-mono text-cyan-300/90 line-clamp-3">{previewModalStyle.promptTokens}</p>
                </div>
              </div>
            </div>

            {/* Modal Bottom Actions */}
            <div className="pt-4 border-t border-slate-800 flex justify-end space-x-3">
              <button
                onClick={() => setPreviewModalStyle(null)}
                className="bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold px-5 py-2.5 rounded-xl text-xs"
              >
                ปิดหน้าต่าง
              </button>

              <button
                onClick={() => {
                  if (currentView === 'wizard') {
                    setWizardData({ ...wizardData, visualStyleId: previewModalStyle.id });
                    showToast(`เลือกสไตล์ "${previewModalStyle.nameTh}" สำหรับโปรเจกต์ใหม่เรียบร้อย`);
                  } else {
                    handleApplyStyleToActiveProject(previewModalStyle);
                  }
                  setPreviewModalStyle(null);
                }}
                className="bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-extrabold px-6 py-2.5 rounded-xl text-xs flex items-center space-x-2 shadow-md"
              >
                <Check className="w-4 h-4" />
                <span>เลือกใช้สไตล์นี้</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================== */}
      {/* MODAL 2: STYLE CHANGE CONFIRMATION GUARD   */}
      {/* ========================================== */}
      {styleChangeModal.isOpen && styleChangeModal.targetStyle && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#0f131c] border border-amber-500/50 rounded-3xl max-w-md w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center space-x-3 text-amber-400">
              <AlertCircle className="w-6 h-6 shrink-0" />
              <h3 className="text-base font-extrabold text-white">ยืนยันการเปลี่ยนสไตล์ภาพยนตร์</h3>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              คุณกำลังจะเปลี่ยนสไตล์ของภาพยนตร์เรื่อง <strong className="text-white">"{activeProject?.title}"</strong> เป็น <strong className="text-cyan-300">"{styleChangeModal.targetStyle.nameTh}"</strong>
            </p>

            <div className="p-3 rounded-xl bg-amber-950/30 border border-amber-900/50 text-[11px] text-amber-200">
              ข้อควรระวัง: การเปลี่ยนสไตล์จะอัปเดตแนวทางภาพ พรอมต์สไตล์ และกฎตัวละครสำหรับฉากถัดไปที่จะเจนเนอเรต
            </div>

            <div className="pt-2 flex justify-end space-x-3">
              <button
                onClick={() => setStyleChangeModal({ isOpen: false, targetStyle: null })}
                className="bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold px-4 py-2 rounded-xl text-xs"
              >
                ยกเลิก
              </button>
              <button
                onClick={confirmStyleChange}
                className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold px-5 py-2 rounded-xl text-xs flex items-center space-x-1.5 shadow"
              >
                <Check className="w-4 h-4" />
                <span>ยืนยันเปลี่ยนสไตล์</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* TOAST NOTIFICATION */}
      {toast && (
        <div className={`fixed bottom-20 right-6 z-50 px-4 py-3 rounded-2xl shadow-2xl border text-xs font-bold flex items-center space-x-2 transition-all animate-bounce ${
          toast.type === 'error' ? 'bg-rose-950 border-rose-700 text-rose-200' : 'bg-cyan-950 border-cyan-700 text-cyan-200'
        }`}>
          {toast.type === 'error' ? <AlertCircle className="w-4 h-4 text-rose-400" /> : <CheckCircle2 className="w-4 h-4 text-cyan-400" />}
          <span>{toast.msg}</span>
        </div>
      )}

    </div>
  );
}