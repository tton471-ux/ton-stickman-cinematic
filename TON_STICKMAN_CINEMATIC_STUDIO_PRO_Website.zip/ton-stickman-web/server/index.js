import express from 'express';
import helmet from 'helmet';
import compression from 'compression';
import rateLimit from 'express-rate-limit';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const app = express();
const PORT = process.env.PORT || 10000;
const GEMINI_API_KEY = process.env.GEMINI_API_KEY;
const IMAGE_MODEL = process.env.GEMINI_IMAGE_MODEL || 'gemini-3.1-flash-image';
const TEXT_MODEL = process.env.GEMINI_TEXT_MODEL || 'gemini-3-flash-preview';
const __dirname = path.dirname(fileURLToPath(import.meta.url));

app.disable('x-powered-by');
app.set('trust proxy', 1);
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"], scriptSrc: ["'self'", "'unsafe-inline'"], styleSrc: ["'self'", "'unsafe-inline'"],
      imgSrc: ["'self'", 'data:', 'blob:'], connectSrc: ["'self'"], fontSrc: ["'self'", 'data:'], objectSrc: ["'none'"], frameAncestors: ["'none'"]
    }
  }
}));
app.use(compression());
app.use(express.json({ limit: '18mb' }));

const apiLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 25, standardHeaders: 'draft-7', legacyHeaders: false,
  message: { error: 'มีการเรียกใช้งานมากเกินไป กรุณารอสักครู่แล้วลองใหม่' } });

app.get('/api/status', (_req, res) => res.json({ ok: true, geminiConfigured: Boolean(GEMINI_API_KEY), imageModel: IMAGE_MODEL, textModel: TEXT_MODEL }));

app.post('/api/gemini/image', apiLimiter, async (req, res) => {
  if (!GEMINI_API_KEY) return res.status(503).json({ error: 'ผู้ดูแลยังไม่ได้ตั้งค่า GEMINI_API_KEY บนเซิร์ฟเวอร์' });
  try {
    const { prompt = '', stylePrompt = '', aspectRatio = '16:9', refImageBase64 = null } = req.body || {};
    if (!prompt.trim() || !stylePrompt.trim()) return res.status(400).json({ error: 'กรุณาระบุคำอธิบายฉากและสไตล์ภาพ' });
    const ratio = ['9:16', '1:1', '16:9'].includes(aspectRatio) ? aspectRatio : '16:9';
    const fullPrompt = `Create a cinematic movie frame image. Subject: ${prompt}. Visual Style & Art Direction: ${stylePrompt}. High quality, detailed composition, aspect ratio ${ratio}. Ensure strict stickman character consistency (thin single-line limbs if applicable).`;
    const parts = [{ text: fullPrompt }];
    if (refImageBase64) {
      const match = /^data:(image\/(?:png|jpeg|jpg|webp));base64,(.+)$/s.exec(refImageBase64);
      if (!match) return res.status(400).json({ error: 'ไฟล์ภาพอ้างอิงไม่ถูกต้อง' });
      parts.push({ inlineData: { mimeType: match[1], data: match[2] } });
    }
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(IMAGE_MODEL)}:generateContent?key=${encodeURIComponent(GEMINI_API_KEY)}`;
    const upstream = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ contents: [{ parts }], generationConfig: { responseModalities: ['IMAGE'], imageConfig: { aspectRatio: ratio } } }) });
    const data = await upstream.json().catch(() => ({}));
    if (!upstream.ok) return res.status(upstream.status).json({ error: data?.error?.message || 'Gemini Image API ไม่สามารถสร้างภาพได้' });
    const imagePart = data?.candidates?.[0]?.content?.parts?.find(part => part.inlineData?.data);
    if (!imagePart) return res.status(502).json({ error: 'Gemini ไม่ได้ส่งข้อมูลภาพกลับมา' });
    const mime = imagePart.inlineData.mimeType || 'image/png';
    return res.json({ image: `data:${mime};base64,${imagePart.inlineData.data}` });
  } catch (error) {
    console.error('Gemini image error:', error.message);
    return res.status(500).json({ error: 'เกิดข้อผิดพลาดระหว่างสร้างภาพ' });
  }
});

app.post('/api/gemini/text', apiLimiter, async (req, res) => {
  if (!GEMINI_API_KEY) return res.status(503).json({ error: 'ผู้ดูแลยังไม่ได้ตั้งค่า GEMINI_API_KEY บนเซิร์ฟเวอร์' });
  try {
    const { systemPrompt = '', userPrompt = '' } = req.body || {};
    if (!userPrompt.trim()) return res.status(400).json({ error: 'กรุณาระบุคำสั่งสร้างเนื้อหา' });
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(TEXT_MODEL)}:generateContent?key=${encodeURIComponent(GEMINI_API_KEY)}`;
    const payload = { contents: [{ parts: [{ text: userPrompt }] }] };
    if (systemPrompt) payload.systemInstruction = { parts: [{ text: systemPrompt }] };
    const upstream = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
    const data = await upstream.json().catch(() => ({}));
    if (!upstream.ok) return res.status(upstream.status).json({ error: data?.error?.message || 'Gemini Text API ไม่สามารถสร้างข้อความได้' });
    const text = data?.candidates?.[0]?.content?.parts?.map(p => p.text || '').join('') || '';
    if (!text) return res.status(502).json({ error: 'Gemini ไม่ได้ส่งข้อความกลับมา' });
    return res.json({ text });
  } catch (error) {
    console.error('Gemini text error:', error.message);
    return res.status(500).json({ error: 'เกิดข้อผิดพลาดระหว่างสร้างข้อความ' });
  }
});

const distPath = path.resolve(__dirname, '../dist');
app.use(express.static(distPath, { maxAge: '1h', etag: true }));
app.get('*', (_req, res) => res.sendFile(path.join(distPath, 'index.html')));

app.listen(PORT, '0.0.0.0', () => console.log(`TON STICKMAN STUDIO listening on ${PORT}`));
